---
version: 1
slug: "src-app-tsx"
primary_target: "src/App.tsx"
related_targets: []
---

# Player surface (Now Playing + Browse + Tune your ear)

Mode: Experience. The song and its light show lead; controls recede.
Audience/job: music and tech lovers on laptop and phone. They want every song to sound the way they love music, more live, without opening an EQ.
Constraints: Audius API only (free, legal); local-only storage; WCAG AA, 44px targets, reduced motion, keyboard control.

## Direction contract

THESIS: Every song gets its own liquid light show, mixed live by how you listen. Refuses the category default: cover art, a scrubber on a flat dark panel, and an EQ sheet hidden in settings.

OWN-WORLD: A projection-dark wall (#120a1f) with one projected dish of light. Oil-and-dye fields in magenta, amber, cyan and violet keep hard edges and displace each other into rings, never blending into soft gradients. Projector-white (#fff4e0) linework for the Sound Shape. Display titles in a fat, curvy poster face; UI in the system stack. Controls are plain literal words.

STORY: The listener presses play and hears the track already tuned to their taste, with a visible note saying why. They drag a point of the shape and hear it change immediately. Aether learns that adjustment for the genre.

FIRST VIEWPORT: A full-bleed light-show canvas. The Sound Shape (7 labelled points, values on leader lines, ghost outline of full reach) sits centred at about 60vmin. The now-playing strip is set low: title, artist, scrubber, play (the primary action), tempo, "Tuned to you" note with undo, and hold-to-compare. The wordmark is top left; Browse and Taste are top right.

FORM: Liquid Light Show, position 4 of the ordered list. seed:2a7ad089a9986453. Raises: hard-edged displacing dye (ebru); values pinned on leader lines (tensegrity); ghost outline for absence (seven-segment); edge-to-edge cover grid with circled loves (event catalog); literal labels (quote grammar). Signature interaction: dragging a shape point pushes dye in the dish while the sound changes live. Motion grammar: dye swells with the bass, the dish slowly rotates with Orbit, and all easing is exponential ease-out.

FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance

## Recorded deviations

- Hold-to-compare shipped as a toggle ("Hear the original", aria-pressed). A hold gesture fails keyboard and switch users, and the user's standing rules forbid timed or hold-only UI. The toggle keeps the A/B one tap away.
- Calm visuals is a labelled pill ("Calm"), justified by PRODUCT.md's reduced-motion requirement; it also follows the OS reduced-motion setting.
- The cover thumbnail was removed from the now-playing deck (THESIS refuses cover art on a flat dark panel). Covers live in the Find music grid.
