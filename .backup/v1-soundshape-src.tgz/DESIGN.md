---
name: Aether
description: A free music player where every song gets its own liquid light show, projected on a dark wall and mixed live by how you listen.
colors:
  lamp: "#fff4e0"
  amber: "#ffb000"
  magenta: "#ff2e88"
  cyan: "#16c7d9"
  violet: "#7b3fe4"
  wall: "#120a1f"
  wall-deep: "#0b0614"
  wall-raised: "#1a1029"
  lamp-2: "#cbbfc2"
  lamp-3: "#a294a6"
  hair: "rgba(255, 244, 224, 0.13)"
typography:
  display:
    fontFamily: "Shrikhand, -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', Roboto, 'Helvetica Neue', Arial, system-ui, sans-serif"
    fontSize: "48px"
    fontWeight: 400
    lineHeight: 1.12
  headline:
    fontFamily: "Shrikhand, -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', Roboto, 'Helvetica Neue', Arial, system-ui, sans-serif"
    fontSize: "32px"
    fontWeight: 400
    lineHeight: 1.1
  title:
    fontFamily: "Shrikhand, -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', Roboto, 'Helvetica Neue', Arial, system-ui, sans-serif"
    fontSize: "26px"
    fontWeight: 400
    lineHeight: 1.2
  body:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', Roboto, 'Helvetica Neue', Arial, system-ui, sans-serif"
    fontSize: "17px"
    fontWeight: 400
    lineHeight: 1.45
  control:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', Roboto, 'Helvetica Neue', Arial, system-ui, sans-serif"
    fontSize: "15px"
    fontWeight: 600
    lineHeight: 1
  label:
    fontFamily: "-apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', Roboto, 'Helvetica Neue', Arial, system-ui, sans-serif"
    fontSize: "13px"
    fontWeight: 600
    lineHeight: 1.3
    fontFeature: "tnum"
rounded:
  bar: "2px"
  card: "18px"
  pill: "999px"
spacing:
  xs: "4px"
  sm: "8px"
  md: "12px"
  lg: "16px"
  xl: "24px"
  xxl: "32px"
components:
  button-primary:
    backgroundColor: "{colors.lamp}"
    textColor: "{colors.wall}"
    typography: "{typography.control}"
    rounded: "{rounded.pill}"
    padding: "0 18px"
    height: "44px"
  button-quiet:
    backgroundColor: "rgba(11, 6, 20, 0.78)"
    textColor: "{colors.lamp}"
    typography: "{typography.control}"
    rounded: "{rounded.pill}"
    padding: "0 18px"
    height: "44px"
  button-quiet-pressed:
    backgroundColor: "{colors.lamp}"
    textColor: "{colors.wall}"
    rounded: "{rounded.pill}"
  button-compare-on:
    backgroundColor: "{colors.amber}"
    textColor: "{colors.wall}"
    rounded: "{rounded.pill}"
  button-play:
    backgroundColor: "{colors.lamp}"
    textColor: "{colors.wall}"
    rounded: "{rounded.pill}"
    size: "56px"
  chip:
    backgroundColor: "transparent"
    textColor: "{colors.lamp-2}"
    rounded: "{rounded.pill}"
    padding: "0 14px"
    height: "44px"
  chip-selected:
    backgroundColor: "{colors.lamp}"
    textColor: "{colors.wall}"
    rounded: "{rounded.pill}"
  input-search:
    backgroundColor: "{colors.wall-deep}"
    textColor: "{colors.lamp}"
    rounded: "{rounded.pill}"
    padding: "0 16px"
    height: "48px"
  panel:
    backgroundColor: "rgba(26, 16, 41, 0.96)"
    textColor: "{colors.lamp}"
    rounded: "{rounded.card}"
    padding: "24px"
  choice-card:
    backgroundColor: "{colors.wall-deep}"
    textColor: "{colors.lamp}"
    rounded: "{rounded.card}"
    padding: "14px 48px 14px 18px"
  choice-card-picked:
    backgroundColor: "rgba(255, 176, 0, 0.1)"
    textColor: "{colors.lamp}"
    rounded: "{rounded.card}"
  text-link:
    textColor: "{colors.amber}"
    typography: "{typography.control}"
---

# Design System: Aether

## Overview

**Creative North Star: "The Liquid Light Show"**

Aether is a projection on a dark wall. One dish of light holds oil-and-dye fields in four colours that keep hard edges and push each other into rings, the way a 1960s overhead-projector show does when the operator presses the glass. Everything else is projector-white linework and lettering thrown onto the same wall: the Sound Shape's lines and labels, the song's poster-face billing, plain-worded controls. The wall is dark because a projection needs one. There is no light theme, and this is a property of the world, not something missing.

Density is low and the song leads. At rest the show drifts slowly and the controls sit quietly at the edges: wordmark top left, actions top right, the song's billing set low. When the music plays the dye swells with the bass, the dish turns with Orbit, and dragging a point of the shape pushes the dye away from your finger while the sound changes. The only chrome that reads as an object is the drawer panel for Find music and Tune your ear, a raised card that sits beside the wall on desktop and below the shrunken dish on phone.

**Key Characteristics:**
- A near-black violet wall with a single circular dish of moving dye, chromatic fringes at its rim, and a faint spill of colour onto the wall around it.
- Four dyes only (magenta, amber, cyan, violet). Each song casts them differently, but no other hue enters the show.
- Projector-white linework: 2px shape outline, 1.25px leader lines, a dashed ghost heptagon for full reach.
- Shrikhand, a fat curvy poster face, for billing and panel titles only; system stack for everything you read or press.
- Pill controls labelled in plain words, and exponential ease-out motion everywhere.

## Colors

A dark wall, projector white for everything the wall shows, and four saturated dyes that belong to the light show, two of which also do jobs in the interface.

### Primary
- **Projector White** (#fff4e0): the light itself. Primary text, the Sound Shape's lines and knobs, the scrubber, the play button's fill, primary pills, and the fill of any pressed or selected pill or chip. Light-on-dark at 17.7:1 on the wall.

### Secondary
- **Marker Amber** (#ffb000): the operator's grease pencil. Keyboard focus rings, the search field's focus border, text links ("Tune your ear", "Undo"), the current step in the tuner, a picked choice card, the on state of "Hear the original", text selection, and the hand-drawn circle around loved covers. 10.5:1 on the wall.

### Tertiary
- **Show Magenta** (#ff2e88): a dye, and the one dye that marks *now playing* in the interface: the 3px inset frame on the current cover and its "Playing now" line. 5.5:1 on the wall, so it can carry text.
- **Show Cyan** (#16c7d9) and **Show Violet** (#7b3fe4): dyes only. They live in the shader and nowhere in the interface.

### Neutral
- **Projection Wall** (#120a1f): the page background and the colour of the unlit wall in the shader. Also the text colour on lamp and amber fills, and the halo stroke behind the Sound Shape's labels.
- **Deep Wall** (#0b0614): recessed surfaces such as the search field, choice cards, and empty cover tiles. At 78% opacity it is the backing of quiet pills, and at 42% it fills the inside of the Sound Shape so the shape reads against the dye.
- **Raised Wall** (#1a1029): the drawer panel, at 96% opacity.
- **Dim Lamp** (#cbbfc2): secondary text such as artist lines, times, values on leader lines, ledes, and unselected chips and segments.
- **Faint Lamp** (#a294a6): tertiary text only: placeholders and the Audius credit. 6.4:1 on the raised panel.
- **Hairline** (lamp at 13%): every border at rest. Hover raises it to lamp at 40%.

### Named Rules
**The Four Dyes Rule.** The show has exactly four dyes. A song's mood picks the lead dye, its id deals the order of the other three, and the set itself never changes. No song, genre or state adds a fifth hue.

**The Dye-Is-Not-Ink Rule.** Cyan and violet never appear as interface colour, and violet (3.4:1 on the wall) never sets text. Amber is the hand that marks things; magenta marks only what is playing now.

**The Lamp-Pressed Rule.** A pressed or selected control fills with Projector White and its text drops to the wall colour. Amber fill is reserved for "Hear the original", because it means the listener has stepped out of their own shape.

## Typography

**Display Font:** Shrikhand (self-hosted via @fontsource, weight 400 only), falling back to the system stack
**Body Font:** the system stack (-apple-system, SF Pro Text, Segoe UI, Roboto, and so on)

**Character:** A fat, swashy 1970s poster face for the song's billing and panel titles, set against the platform's own UI face for everything functional. The poster face says *show*; the system face says *you can press this*.

### Hierarchy
- **Display** (Shrikhand 400, 48px, 1.12): the song title on the deck, on a single line with an ellipsis. It steps down to 36px below 960px, 30px below 640px, and 20px in the mini deck shown while a panel is open on a phone.
- **Headline** (Shrikhand 400, 32px, 1.1): panel titles ("Find music", "Tune your ear"), 26px below 640px. The wordmark uses the same face at 30px, or 26px on phone.
- **Title** (Shrikhand 400, 26px, 1.2): the tuner's question.
- **Body** (system 400, 17px, 1.45): base text. List headings ("Trending this week") and choice labels use it at weight 600. Running prose such as the tuning note and panel ledes drops to 15px in Dim Lamp; the lede is capped at 60ch.
- **Control** (system 600, 15px, line-height 1): pill labels. Chips and tempo segments use 14px, and 13px on phone.
- **Label** (system 600, 13px): Sound Shape axis names, cover titles, and the step counter. Values (500, Dim Lamp) and times use tabular figures.

### Named Rules
**The Poster-Only Rule.** Shrikhand sets billing and titles only, never below 20px, never for controls, values or running text.

**The Halo Rule.** Any text drawn over the moving dye gets a 4px stroke of wall colour painted behind it, so it stays legible whatever colour passes underneath.

## Layout

The app is one viewport-height grid with three rows, top bar, stage and deck, laid over a fixed full-bleed canvas. The page itself never scrolls (body overflow is hidden), and only the panels scroll internally. The stage holds the Sound Shape, centred and sized to the space left, with a reading-width (680px) tuning note under it. The deck is set low across the full width: billing on the left, tempo and "Hear the original" on the right, and transport, scrubber and Love below.

- **960px and up:** opening a panel adds a right column (360 to 420px) that runs from under the top bar to above the deck. The dish moves left and stays fully visible.
- **Below 960px:** the deck stacks into three rows. With a panel open, the stage shrinks to a 150px / 24dvh band, the panel takes the middle, and the deck collapses to a mini deck holding the title and the transport controls, so play/pause stays in reach.
- **Below 640px:** the top pills drop their icons and use short words ("Tune", "Find"), the deck goes to four rows with the transport centred at a 24px gap, and the cover grid's minimum cell width drops from 112px to 96px.
- **Sound Shape:** its radius is computed from the stage box minus room for labels. Below 280px of stage height it goes compact: the labels and values are hidden and only the leader stubs and knobs remain.
- **Safe areas:** the top and bottom padding respect `env(safe-area-inset-*)`.

Spacing runs on 4 / 8 / 16 / 24 / 32, with 12 for in-between gaps such as the scrubber, the phone top bar and the credit line. The page gutter is 24px on desktop and 16px on phone, and the deck's side padding is 32px on desktop.

### Named Rules
**The Edge-to-Edge Catalog Rule.** The cover grid has no column gap. Covers butt against each other like a gig poster wall and bleed to the panel edges (negative margins cancel the panel padding). Rows are separated by 16px of title text only.

## Elevation & Depth

Depth comes from light, not from material. The wall is flat and dark, the dish is the brightest thing on it, and the vignette inside the dish (brighter at the centre, falling off toward the rim) plus the chromatic rim give it the look of a lens. The interface adds only two shadows, and both are soft and ambient.

### Shadow Vocabulary
- **Panel lift** (`box-shadow: 0 24px 48px -16px rgba(0, 0, 0, 0.6)`): the drawer panel, which is the only floating surface.
- **Play lift** (`box-shadow: 0 6px 20px -6px rgba(0, 0, 0, 0.6)`): the play button, so the primary action sits slightly off the wall.

### Named Rules
**The Hard-Dye Rule.** Inside the dish, dyes meet at hard edges with a thin lamp-white seam where two fields touch, and they displace each other into concentric rings. They never cross-fade into a soft gradient. Outside the rim, the faint dye spill onto the wall is projector light and is allowed to be soft.

**The One Dish Rule.** There is exactly one projected dish per screen. Panels and controls sit beside it or over the wall, and the interface never draws a second light source.

## Shapes

There are three corner values and they do not mix. Interactive controls are full pills (999px): buttons, chips, the tempo segments, the search field, and the play and icon buttons, which are circles. Containers you read inside are 18px cards: the drawer panel and the tuner's choice cards. Covers are square and unrounded, because they are posters. The only other radius is 2px on the tuner's progress bars.

The Sound Shape is a seven-point polygon with a 2px round-joined lamp stroke, 7px knob dots that grow to 9.5px on hover or drag, and 24px invisible hit circles. A dashed 1px ghost heptagon (2/6 dash) marks full reach and an inner one marks zero. A circle is the world's recurring silhouette: the dish, the knobs, the play button, and the loose hand-drawn ring around loved covers, which deliberately overshoots its own start.

## Components

### Buttons
Quiet pills on the wall, with one solid lamp disc for play.
- **Shape:** full pill (999px), at least 44px tall, 18px side padding, label 15px/600, with an optional 18px line icon (1.75 stroke) and an 8px gap.
- **Primary:** a Projector White fill with wall-coloured text, used for the tuner's Next and Finish. On hover it goes to pure white.
- **Quiet:** Deep Wall at 78% with a Hairline border and lamp text. Hover raises the border to lamp at 40%. When pressed or expanded (Calm, an open panel) it fills with lamp.
- **Play:** a 56px lamp disc (48px in the mini deck) with a 28px glyph and the Play lift. It scales to 1.05 on hover and 0.97 on press over 0.3s.
- **Icon buttons:** 44px transparent circles for previous, next and close. Hover adds a 10% lamp wash.
- **Text link:** amber, 600, underlined at a 3px offset, with a padded hit area. It is used for in-sentence actions in the tuning note.
- **Focus:** a 2px amber outline at a 2px offset on everything. On Sound Shape knobs it becomes a 14px amber ring.

### Chips
- **Style:** a transparent pill with a Hairline border, Dim Lamp text at 14px/600, and 44px tall. They sit in a horizontally scrolling row that bleeds to the panel edges.
- **State:** selected chips fill with lamp and take wall-coloured text (aria-pressed).

### Tempo segmented control
A Hairline-bordered pill holding three pill segments (Slowed, Normal, Sped up) that work as a radio group. The checked segment fills with lamp.

### Cards / Containers
- **Corner Style:** 18px.
- **Background:** Raised Wall at 96% for the panel, and Deep Wall for choice cards.
- **Shadow Strategy:** Panel lift on the panel only. Choice cards are flat.
- **Border:** Hairline.
- **Internal Padding:** 24px for the panel (16px on phone). Choice cards use 14px with an 18px left inset and a 48px right inset that holds the radio ring.
- **Entrance:** the panel rises 12px over 0.5s. Choice cards bloom in from 96% scale and 8px lower over 0.55s, staggered by 50ms.

### Inputs / Fields
- **Search:** a 48px pill on Deep Wall with a Hairline border, an 18px search icon in Dim Lamp, 16px input text, and placeholders in Faint Lamp.
- **Focus:** the whole pill's border turns amber.
- **Scrubber:** a 2px lamp line, filled to the playhead with lamp at 30% beyond it, and a 16px lamp knob ringed in wall. It is drawn in the same language as the Sound Shape's leader lines. Its hit area is 44px tall.

### Navigation
The Shrikhand wordmark sits top left and quiet pills sit top right ("Calm", "Tune your ear", "Find music", each with a line icon). Below 640px the pills drop their icons and shorten to "Tune" and "Find". An open panel shows its pill in the pressed lamp fill.

### Sound Shape (signature)
Seven labelled axes (Bass, Warmth, Room, Width, Orbit, Air, Punch), each with a spoke at lamp 20%, a leader line running out past the rim, and the axis name (13px/600 lamp) with its value (13px/500 Dim Lamp, tabular) pinned at the end. Values are in plain units ("+5 dB", "136%", "Club", "Still"). The shape's interior is darkened with Deep Wall at 42%. Dragging a knob pushes the dye away from that point in the shader while the audio changes live.

### Cover cell (signature)
A square cover with no radius, a 2-line 13px/600 title and a 13px Dim Lamp meta line inside an 8px inset. Hover lifts the cover's brightness 12% and saturation 10%. The current song gets a 3px magenta inset frame and a magenta "Playing now" meta line. Loved songs get the amber hand-drawn ring (4px round-capped stroke, 114% of the cover) plus a screen-reader ", loved".

### Tuner progress
A row of 4px bars with 2px radius and 6px gaps. Unanswered bars are lamp at 16%, answered bars are lamp, and the current bar is amber, with a 13px tabular "Question n of n" above.

## Do's and Don'ts

### Do:
- **Do** keep the show to the four dyes, and let each song's mood choose the lead.
- **Do** keep dye edges hard inside the dish, with a lamp seam where fields meet. Soft light belongs only to the spill outside the rim.
- **Do** draw anything that sits on the wall as projector-white line and lettering, and give text over the dye a 4px wall-colour halo.
- **Do** label controls in plain words ("Hear the original", "Find music", "Love"), as pills at least 44px tall.
- **Do** ease every interface transition with exponential ease-out (`cubic-bezier(0.16, 1, 0.3, 1)`): 0.2 to 0.3s for state, 0.5s for panels. In the shader, the bass response attacks fast and releases slowly.
- **Do** let Calm and the OS reduced-motion setting both quiet the show. Calm slows drift to 25% and audio reactivity to 15%, and reduced motion collapses CSS animation.
- **Do** keep covers square and edge to edge, and mark loves with the hand-drawn amber circle, not a badge.

### Don't:
- **Don't** add a light theme or a lit background. A projection needs a dark wall.
- **Don't** blend dyes into soft gradients or glows inside the dish, or project a second dish.
- **Don't** set Shrikhand under 20px or use it on controls, values or body text.
- **Don't** use cyan or violet as interface colour, or violet for text.
- **Don't** put cover art on the deck. The song's billing is lettering on the wall.
- **Don't** introduce hold-only or timed controls. A/B listening is a toggle.
