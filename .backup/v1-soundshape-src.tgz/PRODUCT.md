# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack

React + Vite (user's choice). Audio via the Web Audio API; visuals via WebGL/canvas.

## Users

Music and tech enthusiasts who listen a lot and care how a track *feels* (bass weight, space, "live" presence), not only which track plays. They use it on both laptop and phone in equal measure. They have no local music files, and they won't pay for Spotify.

## Product Purpose

A free music player that personalizes the sound of every song to how this listener loves music, and makes recorded tracks feel more live. Success means a listener plays a track and it hits the way they like it without opening an EQ. When they do want to shape it, the control feels like an instrument, not a settings panel.

## Positioning

The **Sound Shape**: the sound engine's parameters (Bass, Warmth, Space, Width, Orbit, Air, Punch) are one draggable constellation. The shape is personal: the app learns it from the listener's taste and from every adjustment they make per genre, and applies it automatically to each new song. Musi- and Spotify-style players play songs but give the listener no access to the audio chain. Aether processes the actual audio, so it can reshape every song.

## Operating Context

- Music source: the Audius open API (free, legal, no account required). Trending, search and genre browsing. No local files assumed.
- Sessions are long listening sessions. The player stays open while the listener does other things, so it must be calm at rest and alive when looked at.

## Capabilities and Constraints

- Real-time audio chain per track: low shelf/sub-bass, saturation (warmth), convolution reverb (space/"live room"), mid/side width, 3D orbit panning, high shelf (air), compression (punch), plus tempo (slowed / sped up).
- Personalization:
  - A short "tune your ear" taste setup gives a starting shape.
  - Every manual adjustment teaches a per-genre shape.
  - New songs get the learned shape automatically, and the change is visible and can be undone.
- "Live feel" is driven by the learned preference: how much room, width and presence this listener likes.
- Everything is stored locally in the browser. There are no accounts and no server.
- Mobile web limitation: background playback on iOS may stop when the tab is hidden.

## Brand Commitments

- Name: **Aether** (working name).
- The user's brief: free, personalized, "universal", dreamy/imaginary, for tech and music lovers. It must not feel like a rookie player, a clone of Musi or Spotify, or AI slop.

## Evidence on Hand

None. There are no testimonials, user counts or benchmarks, and the product must not invent them. Track content comes live from Audius.

## Product Principles

1. The song comes first: the interface recedes while music plays.
2. Personal by default: the app learns from what the listener does, and every automatic change is visible and reversible.
3. Sound control is an instrument: direct manipulation, immediate audible feedback.
4. Free and open: no paywalls, no accounts, legal sources only.

## Accessibility & Inclusion

WCAG AA contrast, 44px touch targets, a reduced-motion mode for the reactive visuals, no meaning carried by color alone, and keyboard control on desktop.
