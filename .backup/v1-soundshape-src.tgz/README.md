# Aether

Aether is a free music player that tunes every song to how you like music and makes it feel live.
Songs come from two free, legal sources:

- [Audius](https://audius.co): studio tracks from independent artists.
- The Internet Archive's [Live Music Archive](https://archive.org/details/etree): about 297,000 concert recordings.

You don't need an account, a subscription or any music files of your own. Big-label releases aren't on either source.

## Finding and keeping music

- **Find music:**
  - Home shows trending songs, trending playlists, rising underground tracks, legendary live shows and genres.
  - Search runs as you type and covers artists, songs (with "More songs"), live recordings and playlists. Recent searches are remembered.
- **Library:** Liked songs, plus your own playlists. You can create, rename, reorder, remove songs and delete playlists.
- **Like** and **Add to playlist** are on the now-playing deck and on every song row.

## Run it

```sh
npm install
npm run dev        # http://localhost:5180 (also reachable from your phone on the same Wi-Fi)
```

## Official songs from any artist (YouTube)

Full official songs (Drake, Taylor Swift, anyone on YouTube) play inside the dish in YouTube's own player. YouTube's terms forbid apps from changing its audio, so those songs keep their original sound and the Sound Shape rests while they play.

To turn it on you need a free YouTube Data API key (about 2 minutes):

1. Open [YouTube Data API v3](https://console.cloud.google.com/apis/library/youtube.googleapis.com) in Google Cloud. Create a free project if asked, then press **Enable**.
2. Go to [Credentials](https://console.cloud.google.com/apis/credentials) and choose **Create credentials → API key**.
3. Paste the key into **Find music → Connect YouTube**. It's stored only in your browser.
   - Alternatively, put it in a `.env.local` file (git-ignored) as `VITE_YOUTUBE_KEY=your-key` and restart `npm run dev`.

A free key covers about 100 searches a day. Searches are cached, and trending and playback barely use the allowance.
Tip: in Google Cloud, restrict the key to "YouTube Data API v3" and to the websites `http://localhost:5180/*` so nobody else can use it.

## How it works

- **Sound Shape:** seven points you drag on the projected dish. Each point is real audio processing applied to the song:
  - **Bass:** low-shelf boost plus a sub-bass peak.
  - **Warmth:** tape saturation.
  - **Room:** convolution reverb that moves from a club room to a hall.
  - **Width:** mid/side stereo widening.
  - **Orbit:** the sound circles your head (8D).
  - **Air:** high-shelf sparkle.
  - **Punch:** compression.
- **Tune your ear:** four quick picks that set your starting sound. You hear each pick as you make it.
- **It learns:** every adjustment you make teaches Aether the shape you like for that genre. Loving a song counts as a vote for how it sounds right now.
- **Per-song fit:** for the first few seconds of each song, Aether measures its tonal balance against what you usually play. If a track is thin or dull compared with your usual listening, Aether nudges Bass or Air up and says so, with an Undo.
- **Hear the original:** bypasses all processing so you can compare.
- **Tempo:** Slowed or Sped up, with the pitch shifting along with the speed.

Your taste profile is stored only in this browser (localStorage).

## Known limits

- On iPhone, music may stop when you lock the screen or switch apps. Browsers there pause web audio in the background.
- Some Audius tracks are gated or region-locked. Aether skips the ones that won't stream.
