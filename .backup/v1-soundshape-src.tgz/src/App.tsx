import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Search, SlidersHorizontal, Moon, RotateCw, Library as LibraryIcon } from 'lucide-react'
import { AudioEngine, type Bands, type Tilt } from './audio/engine'
import { type Shape } from './audio/shape'
import { hashId, trackStream, trending, type Track } from './data/audius'
import {
  adaptToTrack, applyAdaptation, describeDelta, learn, loadProfile, recordTilt, reinforce, saveProfile, shapeFor,
  type Adaptation, type Profile,
} from './taste/profile'
import { LightShow } from './visual/LightShow'
import { bus, setSongPalette } from './visual/bus'
import { SoundShape } from './components/SoundShape'
import { NowPlaying, TEMPO_RATE, type Tempo } from './components/NowPlaying'
import { Browse } from './components/Browse'
import { TasteTuner } from './components/TasteTuner'
import { YouTubeStage, type YTHandle, type YTState } from './components/YouTubeStage'
import { ENV_KEY, trendingVideos, youtubeId } from './data/youtube'
import { Library } from './components/Library'
import { LibraryContext, type LibraryApi } from './library/context'

type Panel = 'browse' | 'taste' | 'library' | null

const reducedMotion = () => {
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches
  } catch {
    return false
  }
}

export default function App() {
  const audioRef = useRef<HTMLAudioElement>(null)
  const engine = useRef<AudioEngine | null>(null)

  const [profile, setProfileState] = useState<Profile>(loadProfile)
  const profileRef = useRef(profile)
  const setProfile = useCallback((fn: (p: Profile) => Profile) => {
    setProfileState((prev) => {
      const next = fn(prev)
      profileRef.current = next
      saveProfile(next)
      return next
    })
  }, [])

  const [queue, setQueue] = useState<Track[]>([])
  const [index, setIndex] = useState(0)
  const track = queue[index] ?? null
  const isYT = track?.source === 'youtube'
  const isYTRef = useRef(false)
  isYTRef.current = isYT
  const yt = useRef<YTHandle>(null)
  const [listState, setListState] = useState<'loading' | 'ready' | 'error'>('loading')
  const [playing, setPlaying] = useState(false)
  const [loading, setLoading] = useState(false)
  const [time, setTime] = useState(0)
  const timeRef = useRef(0)
  timeRef.current = time
  const [duration, setDuration] = useState(0)
  const [tempo, setTempo] = useState<Tempo>('normal')
  const [compare, setCompare] = useState(false)
  const [panel, setPanel] = useState<Panel>(null)

  const [shape, setShape] = useState<Shape>(() => shapeFor(profile, null).shape)
  const shapeRef = useRef(shape)
  shapeRef.current = shape
  const [source, setSource] = useState('')
  const [adaptation, setAdaptation] = useState<Adaptation | null>(null)
  const [notice, setNotice] = useState<string | null>(null)
  const autoShape = useRef<Shape>(shape) // what Aether chose for this song; learning measures your change from it
  const preAdapt = useRef<Shape>(shape)
  const edited = useRef(false)
  const wantPlay = useRef(false)
  const failures = useRef(0)
  const learnTimer = useRef<number>(0)

  // ---- boot
  useEffect(() => {
    const a = audioRef.current!
    engine.current = new AudioEngine(a)
  }, [])

  const loadTrending = useCallback(() => {
    setListState('loading')
    const key = profileRef.current.youtubeKey ?? ENV_KEY
    // With YouTube connected, start on the real hits; otherwise (or if YouTube fails) on Audius.
    const first = key ? trendingVideos(key).then((l) => (l.length ? l : trending(null))).catch(() => trending(null)) : trending(null)
    first
      .then((list) => {
        setQueue(list)
        setIndex(0)
        setListState('ready')
      })
      .catch(() => setListState('error'))
  }, [])
  useEffect(loadTrending, [loadTrending])

  // ---- calm visuals
  useEffect(() => {
    bus.calm = profile.calm || reducedMotion()
  }, [profile.calm])

  // ---- shape → sound + light
  useEffect(() => {
    bus.shape = shape
    engine.current?.apply(shape)
  }, [shape])

  // ---- a new song: reach for the shape this listener would want
  useEffect(() => {
    if (!track) return
    const tn = shapeFor(profileRef.current, track)
    setShape(tn.shape)
    autoShape.current = tn.shape
    preAdapt.current = tn.shape
    edited.current = false
    setSource(tn.source)
    setAdaptation(null)
    setTime(0)
    setDuration(track.duration)
    bus.seed = hashId(track.id)
    setSongPalette(bus.seed, track.mood)

    const a = audioRef.current!
    const vid = youtubeId(track)
    if (vid) {
      // Official song: YouTube's player takes over; Aether's audio element rests.
      a.pause()
      a.removeAttribute('src')
      a.load()
      setCompare(false)
      engine.current?.setCompare(false)
      yt.current?.load(vid, wantPlay.current, TEMPO_RATE[tempo])
      if (wantPlay.current) setLoading(true)
    } else {
      yt.current?.stop()
      a.src = trackStream(track)
      engine.current?.setTempo(TEMPO_RATE[tempo])
      if (wantPlay.current) {
        setLoading(true)
        a.play().catch(() => setLoading(false))
      }
    }
    if ('mediaSession' in navigator) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: track.title,
        artist: track.artist,
        album: 'Aether',
        artwork: track.art ? [{ src: track.art, sizes: '480x480', type: 'image/jpeg' }] : [],
      })
    }
  }, [track?.id]) // eslint-disable-line react-hooks/exhaustive-deps

  // ---- transport
  const play = useCallback(async () => {
    const a = audioRef.current!
    wantPlay.current = true
    if (isYTRef.current) {
      yt.current?.play()
      return
    }
    await engine.current?.ensure()
    if (!a.src && track) a.src = trackStream(track)
    setLoading(true)
    try {
      await a.play()
    } catch {
      setLoading(false)
    }
  }, [track])

  const pause = useCallback(() => {
    wantPlay.current = false
    if (isYTRef.current) yt.current?.pause()
    else audioRef.current?.pause()
  }, [])

  const toggle = useCallback(() => (playing ? pause() : play()), [playing, play, pause])

  const next = useCallback(() => {
    if (!queue.length) return
    wantPlay.current = true
    setNotice(null)
    setIndex((i) => (i + 1) % queue.length)
  }, [queue.length])

  const prev = useCallback(() => {
    const a = audioRef.current!
    const now = isYTRef.current ? timeRef.current : a.currentTime
    if (now > 3 || queue.length < 2) {
      if (isYTRef.current) yt.current?.seek(0)
      else a.currentTime = 0
      return
    }
    wantPlay.current = true
    setNotice(null)
    setIndex((i) => (i - 1 + queue.length) % queue.length)
  }, [queue.length])

  const playFrom = useCallback(
    (list: Track[], i: number) => {
      wantPlay.current = true
      engine.current?.ensure()
      if (list[i]?.id === track?.id) {
        play()
        return
      }
      setNotice(null)
      setQueue(list)
      setIndex(i)
    },
    [track?.id, play],
  )

  // ---- audio element events
  useEffect(() => {
    const a = audioRef.current!
    const on = {
      play: () => setPlaying(true),
      playing: () => {
        setLoading(false)
        failures.current = 0
      },
      pause: () => setPlaying(false),
      waiting: () => setLoading(true),
      canplay: () => setLoading(false),
      timeupdate: () => setTime(a.currentTime),
      durationchange: () => Number.isFinite(a.duration) && setDuration(a.duration),
      ended: () => next(),
      error: () => {
        if (!a.getAttribute('src') || !track || isYTRef.current) return
        setLoading(false)
        failures.current += 1
        if (failures.current <= 3 && wantPlay.current) {
          setNotice(`“${track.title}” wouldn't stream, so Aether skipped to the next song.`)
          next()
        } else {
          setNotice("Songs aren't streaming right now. Check your connection, then press play.")
          wantPlay.current = false
        }
      },
    }
    for (const [k, f] of Object.entries(on)) a.addEventListener(k, f)
    return () => {
      for (const [k, f] of Object.entries(on)) a.removeEventListener(k, f)
    }
  }, [next, track])

  useEffect(() => {
    bus.playing = playing
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = playing ? 'playing' : 'paused'
      navigator.mediaSession.setActionHandler('play', () => play())
      navigator.mediaSession.setActionHandler('pause', () => pause())
      navigator.mediaSession.setActionHandler('nexttrack', () => next())
      navigator.mediaSession.setActionHandler('previoustrack', () => prev())
    }
  }, [playing, play, pause, next, prev])

  // ---- per-song fit: listen to the song itself for a few seconds, then lean it toward this listener
  const measured = useRef<string | null>(null)
  const samples = useRef<Tilt[]>([])
  useEffect(() => {
    if (!playing || !track || measured.current === track.id || track.source === 'youtube') return
    const id = track.id
    const timer = window.setInterval(() => {
      const a = audioRef.current!
      if (a.currentTime < 2) return
      const tilt = engine.current?.readTilt()
      if (tilt) samples.current.push(tilt)
      if (samples.current.length < 18) return
      window.clearInterval(timer)
      measured.current = id
      const s = samples.current
      samples.current = []
      const avg = { low: s.reduce((x, y) => x + y.low, 0) / s.length, high: s.reduce((x, y) => x + y.high, 0) / s.length }
      const p = profileRef.current
      if (p.autoTune && !edited.current) {
        const ad = adaptToTrack(p, autoShape.current, avg)
        if (ad) {
          preAdapt.current = autoShape.current
          const adapted = applyAdaptation(autoShape.current, ad)
          autoShape.current = adapted
          setShape(adapted)
          setAdaptation(ad)
        }
      }
      setProfile((pp) => recordTilt(pp, avg))
    }, 300)
    return () => {
      window.clearInterval(timer)
      samples.current = []
    }
  }, [playing, track, setProfile])

  // ---- shaping by hand teaches the genre
  const onShapeChange = (s: Shape) => {
    edited.current = true
    setShape(s)
  }
  const onShapeCommit = () => {
    window.clearTimeout(learnTimer.current)
    learnTimer.current = window.setTimeout(() => {
      const genre = track?.genre || 'Unknown'
      const before = profileRef.current
      const after = learn(before, genre, shapeRef.current, autoShape.current)
      if (after === before) return
      setProfile(() => after)
      autoShape.current = shapeRef.current
      const n = after.genres[genre]?.n ?? 1
      setNotice(
        genre === 'Unknown'
          ? 'Saved to your taste. New songs will start closer to this.'
          : `Saved to your ${genre} shape (${n} ${n === 1 ? 'adjustment' : 'adjustments'}). ${genre} songs will start this way.`,
      )
    }, 900)
  }

  const undoAdaptation = () => {
    setShape(preAdapt.current)
    autoShape.current = preAdapt.current
    setAdaptation(null)
    setNotice('Fit for this song undone. Playing your shape as is.')
  }

  const toggleLike = useCallback(
    (t: Track) => {
      const isLiked = !!profileRef.current.loved[t.id]
      const isCurrent = t.id === track?.id
      setProfile((p) => {
        const loved = { ...p.loved }
        if (isLiked) {
          delete loved[t.id]
          return { ...p, loved }
        }
        loved[t.id] = t
        // Liking what's playing is a vote for how it sounds right now.
        return isCurrent ? reinforce({ ...p, loved }, t.genre || 'Unknown', shapeRef.current) : { ...p, loved }
      })
      if (isCurrent) {
        setNotice(isLiked ? null : `Liked. This sound now counts toward your ${t.genre !== 'Unknown' ? t.genre + ' ' : ''}shape.`)
      }
    },
    [track?.id, setProfile],
  )

  const changeTempo = (t: Tempo) => {
    setTempo(t)
    engine.current?.setTempo(TEMPO_RATE[t])
    if (isYTRef.current) yt.current?.rate(TEMPO_RATE[t])
  }
  const changeCompare = (on: boolean) => {
    setCompare(on)
    engine.current?.setCompare(on)
    bus.shape = on ? { bass: 0, warmth: 0, room: 0, width: 0, orbit: 0, air: 0, punch: 0 } : shapeRef.current
  }

  // ---- keyboard
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement
      if (el.closest('input, textarea, select, [role="slider"], button, [contenteditable]')) {
        if (e.key === 'Escape') setPanel(null)
        return
      }
      if (e.key === ' ') {
        e.preventDefault()
        toggle()
      } else if (e.key === 'n') next()
      else if (e.key === 'p') prev()
      else if (e.key === 'f' || e.key === '/') {
        e.preventDefault()
        setPanel('browse')
      } else if (e.key === 'Escape') setPanel(null)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [toggle, next, prev])

  const readBands = useCallback((out: Bands) => {
    if (!engine.current || !bus.playing) {
      out.low = out.mid = out.high = out.level = 0
      return out
    }
    return engine.current.readBands(out)
  }, [])

  const onYTState = useCallback(
    (st: YTState) => {
      if (!isYTRef.current) return
      if (st === 'playing') {
        setPlaying(true)
        setLoading(false)
        failures.current = 0
      } else if (st === 'paused') setPlaying(false)
      else if (st === 'buffering') setLoading(true)
      else if (st === 'ended') next()
    },
    [next],
  )
  const onYTTime = useCallback((t: number, d: number) => {
    if (!isYTRef.current) return
    setTime(t)
    if (d) setDuration(d)
  }, [])
  const onYTError = useCallback(
    (code: number) => {
      if (!isYTRef.current || !track) return
      setLoading(false)
      failures.current += 1
      const why = code === 101 || code === 150 ? "its owner doesn't allow it to play outside YouTube" : "YouTube couldn't play it"
      if (failures.current <= 3) {
        setNotice(`“${track.title}” was skipped: ${why}.`)
        next()
      } else {
        setNotice(`“${track.title}” can't play here: ${why}.`)
        wantPlay.current = false
      }
    },
    [track, next],
  )

  const ytKey = profile.youtubeKey ?? ENV_KEY

  const library = useMemo<LibraryApi>(() => {
    const editPlaylists = (fn: (pls: Profile['playlists']) => Profile['playlists']) => setProfile((p) => ({ ...p, playlists: fn(p.playlists) }))
    return {
      currentId: track?.id ?? null,
      playing,
      liked: profile.loved,
      playlists: profile.playlists,
      recent: profile.recentSearches,
      toggleLike,
      play: playFrom,
      createPlaylist: (name, first) => {
        const id = `pl_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`
        editPlaylists((pls) => [...pls, { id, name, tracks: first ? [first] : [], created: Date.now() }])
        if (first) setNotice(`Added “${first.title}” to “${name}”.`)
        return id
      },
      renamePlaylist: (id, name) => editPlaylists((pls) => pls.map((x) => (x.id === id ? { ...x, name } : x))),
      deletePlaylist: (id) => editPlaylists((pls) => pls.filter((x) => x.id !== id)),
      toggleInPlaylist: (id, t) =>
        editPlaylists((pls) =>
          pls.map((x) =>
            x.id !== id ? x : x.tracks.some((y) => y.id === t.id) ? { ...x, tracks: x.tracks.filter((y) => y.id !== t.id) } : { ...x, tracks: [...x.tracks, t] },
          ),
        ),
      removeFromPlaylist: (id, trackId) => editPlaylists((pls) => pls.map((x) => (x.id === id ? { ...x, tracks: x.tracks.filter((y) => y.id !== trackId) } : x))),
      movePlaylistTrack: (id, from, to) =>
        editPlaylists((pls) =>
          pls.map((x) => {
            if (x.id !== id || to < 0 || to >= x.tracks.length) return x
            const tracks = [...x.tracks]
            const [m] = tracks.splice(from, 1)
            tracks.splice(to, 0, m)
            return { ...x, tracks }
          }),
        ),
      addRecent: (q) => setProfile((p) => ({ ...p, recentSearches: [q, ...p.recentSearches.filter((r) => r.toLowerCase() !== q.toLowerCase())].slice(0, 8) })),
      clearRecent: () => setProfile((p) => ({ ...p, recentSearches: [] })),
      ytKey,
      setYtKey: (k) => setProfile((p) => ({ ...p, youtubeKey: k })),
    }
  }, [track?.id, playing, profile.loved, profile.playlists, profile.recentSearches, ytKey, toggleLike, playFrom, setProfile])

  const openPanel = (p: Panel) => {
    if (panel === 'taste' && p !== 'taste') setShape(autoShape.current)
    setPanel(panel === p ? null : p)
  }

  const finishTaste = (s: Shape) => {
    setProfile((p) => ({ ...p, base: s, setupDone: true }))
    autoShape.current = s
    preAdapt.current = s
    setShape(s)
    setSource('your taste')
    setAdaptation(null)
    setPanel(null)
    setNotice('Saved. Every song now starts from your sound, and keeps learning as you adjust.')
  }

  const closeTaste = () => {
    setShape(autoShape.current)
    setPanel(null)
  }

  return (
    <LibraryContext.Provider value={library}>
    <div className={`app${panel ? ' has-panel' : ''}${isYT ? ' is-video' : ''}`}>
      <LightShow readBands={readBands} />
      <audio ref={audioRef} preload="metadata" crossOrigin="anonymous" />

      <header className="top">
        <span className="wordmark">Aether</span>
        <nav className="top-actions" aria-label="Aether">
          <button
            className="pill pill-quiet"
            aria-pressed={profile.calm}
            onClick={() => setProfile((p) => ({ ...p, calm: !p.calm }))}
            title="Slower light, less movement"
          >
            <Moon size={18} strokeWidth={1.75} aria-hidden="true" />
            <span>Calm</span>
          </button>
          <button className="pill pill-quiet" aria-expanded={panel === 'taste'} onClick={() => openPanel('taste')}>
            <SlidersHorizontal size={18} strokeWidth={1.75} aria-hidden="true" />
            <span className="long">Tune your ear</span>
            <span className="short">Tune</span>
          </button>
          <button className="pill pill-quiet" aria-expanded={panel === 'browse'} onClick={() => openPanel('browse')}>
            <Search size={18} strokeWidth={1.75} aria-hidden="true" />
            <span className="long">Find music</span>
            <span className="short">Find</span>
          </button>
          <button className="pill pill-quiet" aria-expanded={panel === 'library'} onClick={() => openPanel('library')}>
            <LibraryIcon size={18} strokeWidth={1.75} aria-hidden="true" />
            <span className="long">Library</span>
            <span className="short">Library</span>
          </button>
        </nav>
      </header>

      <main className={`stage${isYT ? ' is-video' : ''}`}>
        <SoundShape shape={shape} onChange={onShapeChange} onCommit={onShapeCommit} />
        <YouTubeStage ref={yt} visible={isYT} title={track?.title ?? ''} onState={onYTState} onTime={onYTTime} onError={onYTError} />
        <div className="tuning" aria-live="polite">
          {listState === 'error' ? (
            <p>
              Couldn't reach Audius to find music.{' '}
              <button className="text-btn" onClick={loadTrending}>
                <RotateCw size={14} strokeWidth={2} aria-hidden="true" /> Try again
              </button>
            </p>
          ) : notice ? (
            <p>{notice}</p>
          ) : isYT ? (
            <p>
              <strong>Official song from YouTube</strong> · playing its original sound. YouTube doesn't let apps reshape its audio, so your
              Sound Shape rests until the next Aether song.
            </p>
          ) : compare ? (
            <p>Hearing the song exactly as released. Switch back to hear your shape.</p>
          ) : (
            <>
              <p>
                <strong>Tuned to you</strong> · starting from {source || 'a starter shape'}.
                {!profile.setupDone && (
                  <>
                    {' '}
                    <button className="text-btn" onClick={() => openPanel('taste')}>
                      Tune your ear
                    </button>
                  </>
                )}
              </p>
              {adaptation && (
                <p>
                  {describeDelta(adaptation)} for this song: it's {adaptation.reasons.join(' and ')}.{' '}
                  <button className="text-btn" onClick={undoAdaptation}>
                    Undo
                  </button>
                </p>
              )}
            </>
          )}
        </div>
      </main>

      {panel && (
        <aside className="drawer">
          {panel === 'browse' ? (
            <Browse onClose={() => setPanel(null)} />
          ) : panel === 'library' ? (
            <Library onClose={() => setPanel(null)} />
          ) : (
            <TasteTuner
              start={profile.base}
              playing={playing}
              onPlay={play}
              onPreview={(s) => setShape(s)}
              onFinish={finishTaste}
              onClose={closeTaste}
            />
          )}
        </aside>
      )}

      <NowPlaying
        track={track}
        playing={playing}
        loading={loading}
        time={time}
        duration={duration}
        tempo={tempo}
        loved={!!(track && profile.loved[track.id])}
        compare={compare}
        canCompare={!isYT}
        onToggle={toggle}
        onPrev={prev}
        onNext={next}
        onSeek={(t) => {
          if (isYTRef.current) yt.current?.seek(t)
          else audioRef.current!.currentTime = t
          setTime(t)
        }}
        onTempo={changeTempo}
        onLove={() => track && toggleLike(track)}
        onCompare={changeCompare}
      />
    </div>
    </LibraryContext.Provider>
  )
}
