import type { Shape } from './shape'

const db = (d: number) => Math.pow(10, d / 20)
const smooth = (e0: number, e1: number, x: number) => {
  const t = Math.min(1, Math.max(0, (x - e0) / (e1 - e0)))
  return t * t * (3 - 2 * t)
}

/** A synthetic room: a few early reflections, then a diffuse tail that darkens as it decays. */
function makeRoom(ctx: BaseAudioContext, seconds: number, decay: number, early: number[]): AudioBuffer {
  const rate = ctx.sampleRate
  const len = Math.floor(rate * seconds)
  const buf = ctx.createBuffer(2, len, rate)
  for (let c = 0; c < 2; c++) {
    const d = buf.getChannelData(c)
    for (const t of early) {
      const i = Math.floor((t + (c ? 0.0031 : 0)) * rate)
      if (i < len) d[i] += (0.35 + Math.random() * 0.45) * (Math.random() < 0.5 ? -1 : 1)
    }
    let y = 0
    for (let i = 0; i < len; i++) {
      const t = i / len
      const x = (Math.random() * 2 - 1) * Math.pow(1 - t, decay) * 0.45
      const a = 0.85 - 0.7 * t // the tail loses its highs as it fades, like a real hall
      y += a * (x - y)
      d[i] += y
    }
  }
  return buf
}

function makeTapeCurve(k: number) {
  const n = 2048
  const curve = new Float32Array(n)
  const norm = Math.tanh(k)
  for (let i = 0; i < n; i++) {
    const x = (i / (n - 1)) * 2 - 1
    curve[i] = Math.tanh(k * x) / norm
  }
  return curve
}

export type Bands = { low: number; mid: number; high: number; level: number }
export type Tilt = { low: number; high: number }

/**
 * The Aether signal chain. Every shape axis maps to real processing on the actual audio:
 * bass/air shelves, tape saturation, compression, mid/side width, an orbiting panner and
 * two convolution rooms (club and hall) that make a recording feel live.
 */
export class AudioEngine {
  readonly audio: HTMLAudioElement
  ctx: AudioContext | null = null
  private n: Record<string, AudioNode> = {}
  private freq = new Uint8Array(0)
  private tiltBuf = new Float32Array(0)
  private lfo: OscillatorNode | null = null
  private shape: Shape | null = null
  private compare = false

  constructor(audio: HTMLAudioElement) {
    this.audio = audio
  }

  /** Must run inside a user gesture the first time (browsers block audio until then). */
  async ensure() {
    if (!this.ctx) this.build()
    if (this.ctx && this.ctx.state !== 'running') await this.ctx.resume()
  }

  private build() {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    const ctx = new Ctx({ latencyHint: 'playback' })
    this.ctx = ctx
    const src = ctx.createMediaElementSource(this.audio)

    const g = (v = 1) => {
      const node = ctx.createGain()
      node.gain.value = v
      return node
    }
    const biquad = (type: BiquadFilterType, f: number, q = 0.7) => {
      const b = ctx.createBiquadFilter()
      b.type = type
      b.frequency.value = f
      b.Q.value = q
      return b
    }

    // What the song sounds like before we touch it, for honest per-track analysis.
    const inputTap = ctx.createAnalyser()
    inputTap.fftSize = 4096
    inputTap.smoothingTimeConstant = 0.85
    src.connect(inputTap)

    const wet = g(1) // processed path
    const bypass = g(0) // "hear original" path
    src.connect(wet)
    src.connect(bypass)

    const trim = g(1) // loudness match so boosts are not mistaken for "better"
    const bass = biquad('lowshelf', 110)
    const sub = biquad('peaking', 52, 0.9)
    const body = biquad('peaking', 260, 0.8)
    const air = biquad('highshelf', 9000)
    wet.connect(trim).connect(bass).connect(sub).connect(body).connect(air)

    const warmDry = g(1)
    const warmWet = g(0)
    const shaper = ctx.createWaveShaper()
    shaper.curve = makeTapeCurve(2.6)
    shaper.oversample = '4x'
    const warmSum = g(1)
    air.connect(warmDry).connect(warmSum)
    air.connect(shaper).connect(warmWet).connect(warmSum)

    const comp = ctx.createDynamicsCompressor()
    comp.attack.value = 0.012
    comp.release.value = 0.16
    comp.knee.value = 6
    const makeup = g(1)
    warmSum.connect(comp).connect(makeup)

    // Mid/side width: L' = aL + bR, R' = aR + bL
    const up = g(1)
    up.channelCount = 2
    up.channelCountMode = 'explicit'
    up.channelInterpretation = 'speakers'
    const split = ctx.createChannelSplitter(2)
    const merge = ctx.createChannelMerger(2)
    const ll = g(1), rr = g(1), lr = g(0), rl = g(0)
    makeup.connect(up).connect(split)
    split.connect(ll, 0).connect(merge, 0, 0)
    split.connect(rl, 1).connect(merge, 0, 0)
    split.connect(rr, 1).connect(merge, 0, 1)
    split.connect(lr, 0).connect(merge, 0, 1)

    const pan = ctx.createStereoPanner()
    merge.connect(pan)
    const lfo = ctx.createOscillator()
    lfo.type = 'sine'
    lfo.frequency.value = 0.08
    const orbitDepth = g(0)
    lfo.connect(orbitDepth).connect(pan.pan)
    lfo.start()
    this.lfo = lfo

    const dry = g(1)
    const pre = ctx.createDelay(0.1)
    pre.delayTime.value = 0.022
    const club = ctx.createConvolver()
    club.buffer = makeRoom(ctx, 1.3, 3.2, [0.009, 0.015, 0.023, 0.031])
    const hall = ctx.createConvolver()
    hall.buffer = makeRoom(ctx, 3.6, 2.4, [0.017, 0.029, 0.041, 0.057, 0.071])
    const clubGain = g(0)
    const hallGain = g(0)

    const master = g(1)
    pan.connect(dry).connect(master)
    pan.connect(pre)
    pre.connect(club).connect(clubGain).connect(master)
    pre.connect(hall).connect(hallGain).connect(master)
    bypass.connect(master)

    // Safety limiter so heavy shapes never clip.
    const limiter = ctx.createDynamicsCompressor()
    limiter.threshold.value = -1.5
    limiter.knee.value = 0
    limiter.ratio.value = 20
    limiter.attack.value = 0.002
    limiter.release.value = 0.12
    const out = ctx.createAnalyser()
    out.fftSize = 1024
    out.smoothingTimeConstant = 0.78
    master.connect(limiter).connect(out).connect(ctx.destination)

    this.freq = new Uint8Array(out.frequencyBinCount)
    this.tiltBuf = new Float32Array(inputTap.frequencyBinCount)
    this.n = { wet, bypass, trim, bass, sub, body, air, warmDry, warmWet, comp, makeup, ll, rr, lr, rl, orbitDepth, dry, clubGain, hallGain, out, inputTap }

    if (this.shape) this.apply(this.shape, true)
    this.setCompare(this.compare)
  }

  apply(s: Shape, immediate = false) {
    this.shape = s
    const ctx = this.ctx
    if (!ctx) return
    const n = this.n as Record<string, any> // eslint-disable-line @typescript-eslint/no-explicit-any
    const t = ctx.currentTime
    const tc = immediate ? 0.005 : 0.06
    const set = (p: AudioParam, v: number) => p.setTargetAtTime(v, t, tc)

    set(n.bass.gain, s.bass * 10)
    set(n.sub.gain, s.bass * 4)
    set(n.body.gain, s.warmth * 2.5)
    set(n.air.gain, s.air * 9)
    set(n.trim.gain, db(-(s.bass * 12) * 0.4 - s.air * 9 * 0.2 - s.warmth * 2))

    set(n.warmDry.gain, 1 - s.warmth * 0.45)
    set(n.warmWet.gain, s.warmth * 0.55)

    set(n.comp.threshold, -4 - s.punch * 26)
    set(n.comp.ratio, 1 + s.punch * 5)
    set(n.makeup.gain, db(s.punch * 7))

    const w = 1 + s.width * 1.2
    const a = (1 + w) / 2
    const b = (1 - w) / 2
    set(n.ll.gain, a)
    set(n.rr.gain, a)
    set(n.lr.gain, b)
    set(n.rl.gain, b)

    set(n.orbitDepth.gain, Math.min(1, s.orbit * 1.4))
    if (this.lfo) set(this.lfo.frequency, 0.05 + s.orbit * 0.25)

    const r = s.room
    set(n.dry.gain, 1 - r * 0.3)
    set(n.clubGain.gain, 0.5 * Math.min(1, r / 0.3) * (1 - smooth(0.45, 0.95, r)))
    set(n.hallGain.gain, 0.55 * smooth(0.3, 1, r))
  }

  setCompare(original: boolean) {
    this.compare = original
    if (!this.ctx) return
    const n = this.n as Record<string, GainNode>
    const t = this.ctx.currentTime
    n.wet.gain.setTargetAtTime(original ? 0 : 1, t, 0.04)
    n.bypass.gain.setTargetAtTime(original ? 1 : 0, t, 0.04)
  }

  setTempo(rate: number) {
    const a = this.audio as HTMLAudioElement & { preservesPitch?: boolean; webkitPreservesPitch?: boolean }
    a.preservesPitch = false // slowed sounds deeper, sped up sounds brighter, like the edits people love
    a.webkitPreservesPitch = false
    a.playbackRate = rate
  }

  /** Output energy per band, 0..1, for the light show. */
  readBands(out: Bands): Bands {
    const an = this.n.out as AnalyserNode | undefined
    if (!an || !this.ctx) {
      out.low = out.mid = out.high = out.level = 0
      return out
    }
    an.getByteFrequencyData(this.freq)
    const hz = this.ctx.sampleRate / an.fftSize
    const avg = (f0: number, f1: number) => {
      const i0 = Math.max(1, Math.floor(f0 / hz))
      const i1 = Math.min(this.freq.length - 1, Math.ceil(f1 / hz))
      let s = 0
      for (let i = i0; i <= i1; i++) s += this.freq[i]
      return s / ((i1 - i0 + 1) * 255)
    }
    out.low = avg(30, 160)
    out.mid = avg(300, 2500)
    out.high = avg(4000, 12000)
    out.level = (out.low + out.mid + out.high) / 3
    return out
  }

  /** The song's own tonal balance (before Aether), in dB relative to its mids. */
  readTilt(): Tilt | null {
    const an = this.n.inputTap as AnalyserNode | undefined
    if (!an || !this.ctx) return null
    an.getFloatFrequencyData(this.tiltBuf)
    const hz = this.ctx.sampleRate / an.fftSize
    const avg = (f0: number, f1: number) => {
      const i0 = Math.max(1, Math.floor(f0 / hz))
      const i1 = Math.ceil(f1 / hz)
      let s = 0
      for (let i = i0; i <= i1; i++) s += this.tiltBuf[i]
      return s / (i1 - i0 + 1)
    }
    const mid = avg(300, 3000)
    if (!Number.isFinite(mid) || mid < -110) return null // silence
    return { low: avg(40, 160) - mid, high: avg(5000, 12000) - mid }
  }
}
