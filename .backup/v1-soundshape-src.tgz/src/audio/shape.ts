export const AXES = ['bass', 'warmth', 'room', 'width', 'orbit', 'air', 'punch'] as const
export type Axis = (typeof AXES)[number]

/** Every axis runs 0..1. Zero is "untouched": a flat shape plays the song as recorded. */
export type Shape = Record<Axis, number>

export const FLAT: Shape = { bass: 0, warmth: 0, room: 0, width: 0, orbit: 0, air: 0, punch: 0 }

export const STARTER: Shape = { bass: 0.4, warmth: 0.2, room: 0.28, width: 0.3, orbit: 0, air: 0.3, punch: 0.3 }

function roomName(v: number) {
  if (v < 0.04) return 'Studio'
  if (v < 0.3) return 'Club'
  if (v < 0.55) return 'Theatre'
  if (v < 0.8) return 'Arena'
  return 'Cathedral'
}

export const AXIS_INFO: Record<Axis, { label: string; hint: string; readout: (v: number) => string }> = {
  bass: { label: 'Bass', hint: 'Low end you feel in your chest', readout: (v) => `+${Math.round(v * 12)} dB` },
  warmth: { label: 'Warmth', hint: 'Tape saturation, like vinyl', readout: (v) => (v < 0.03 ? 'Clean' : `${Math.round(v * 100)}%`) },
  room: { label: 'Room', hint: 'How live: studio to cathedral', readout: roomName },
  width: { label: 'Width', hint: 'How wide the stereo spreads', readout: (v) => `${Math.round(100 + v * 120)}%` },
  orbit: { label: 'Orbit', hint: 'Sound circling your head', readout: (v) => (v < 0.03 ? 'Still' : `${(0.05 + v * 0.25).toFixed(2)} Hz`) },
  air: { label: 'Air', hint: 'Sparkle and detail up top', readout: (v) => `+${Math.round(v * 9)} dB` },
  punch: { label: 'Punch', hint: 'Drums hit harder, quiet parts lift', readout: (v) => `${(1 + v * 5).toFixed(1)}:1` },
}

export const clamp01 = (v: number) => Math.min(1, Math.max(0, v))

export function mix(a: Shape, b: Shape, t: number): Shape {
  const out = { ...a }
  for (const k of AXES) out[k] = clamp01(a[k] + (b[k] - a[k]) * t)
  return out
}

export function add(a: Shape, delta: Partial<Shape>): Shape {
  const out = { ...a }
  for (const k of AXES) out[k] = clamp01(a[k] + (delta[k] ?? 0))
  return out
}

export function distance(a: Shape, b: Shape) {
  let d = 0
  for (const k of AXES) d += Math.abs(a[k] - b[k])
  return d
}

export function sanitize(s: unknown, fallback: Shape): Shape {
  const out = { ...fallback }
  if (s && typeof s === 'object') {
    for (const k of AXES) {
      const v = (s as Record<string, unknown>)[k]
      if (typeof v === 'number' && Number.isFinite(v)) out[k] = clamp01(v)
    }
  }
  return out
}
