import { useEffect, useId, useLayoutEffect, useRef, useState, type FormEvent, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { Check, ListPlus, Plus } from 'lucide-react'
import type { Track } from '../data/audius'
import { useLibrary } from '../library/context'

type Props = {
  track: Track | null
  /** Visible label for a pill trigger; omit for an icon-only row action. */
  label?: ReactNode
  className?: string
}

/** A small popover to put a song into one or more of your playlists, or start a new one with it. */
export function AddToPlaylist({ track, label, className }: Props) {
  const lib = useLibrary()
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [pos, setPos] = useState({ left: 0, top: 0, up: false })
  const btn = useRef<HTMLButtonElement>(null)
  const pop = useRef<HTMLDivElement>(null)
  const input = useRef<HTMLInputElement>(null)
  const titleId = useId()

  useLayoutEffect(() => {
    if (!open || !btn.current) return
    const r = btn.current.getBoundingClientRect()
    const w = 280
    const left = Math.min(Math.max(8, r.right - w), window.innerWidth - w - 8)
    const up = r.top > window.innerHeight / 2
    setPos({ left, top: up ? r.top - 8 : r.bottom + 8, up })
  }, [open])

  useEffect(() => {
    if (!open) return
    const close = (e: PointerEvent) => {
      if (!pop.current?.contains(e.target as Node) && !btn.current?.contains(e.target as Node)) setOpen(false)
    }
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation()
        setOpen(false)
        btn.current?.focus()
      }
    }
    document.addEventListener('pointerdown', close)
    document.addEventListener('keydown', key, true)
    ;(pop.current?.querySelector('button, input') as HTMLElement | null)?.focus()
    return () => {
      document.removeEventListener('pointerdown', close)
      document.removeEventListener('keydown', key, true)
    }
  }, [open])

  const create = (e: FormEvent) => {
    e.preventDefault()
    if (!track) return
    const n = name.trim() || `My playlist ${lib.playlists.length + 1}`
    lib.createPlaylist(n, track)
    setName('')
    setOpen(false)
    btn.current?.focus()
  }

  return (
    <>
      <button
        ref={btn}
        className={className ?? (label ? 'pill pill-quiet' : 'icon-btn')}
        onClick={() => setOpen(!open)}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-label={label ? undefined : track ? `Add “${track.title}” to a playlist` : 'Add to a playlist'}
        title={label ? undefined : 'Add to a playlist'}
        disabled={!track}
      >
        <ListPlus size={label ? 18 : 20} strokeWidth={1.75} aria-hidden="true" />
        {label}
      </button>
      {open &&
        track &&
        createPortal(
          <div
            ref={pop}
            className={`popover${pos.up ? ' is-up' : ''}`}
            style={{ left: pos.left, top: pos.top }}
            role="dialog"
            aria-labelledby={titleId}
          >
            <p id={titleId} className="popover-title">
              Add to playlist
            </p>
            {lib.playlists.length > 0 && (
              <ul className="popover-list">
                {lib.playlists.map((p) => {
                  const has = p.tracks.some((t) => t.id === track.id)
                  return (
                    <li key={p.id}>
                      <button className="popover-item" aria-pressed={has} onClick={() => lib.toggleInPlaylist(p.id, track)}>
                        <span className="popover-check" aria-hidden="true">
                          {has && <Check size={16} strokeWidth={2.5} />}
                        </span>
                        <span className="popover-name">{p.name}</span>
                        <span className="popover-count">{p.tracks.length}</span>
                      </button>
                    </li>
                  )
                })}
              </ul>
            )}
            <form className="popover-new" onSubmit={create}>
              <input
                ref={input}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="New playlist name"
                aria-label="New playlist name"
                maxLength={60}
              />
              <button className="pill pill-primary" type="submit">
                <Plus size={16} strokeWidth={2} aria-hidden="true" /> Create
              </button>
            </form>
          </div>,
          document.body,
        )}
    </>
  )
}
