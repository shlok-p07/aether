import { useEffect, useRef, useState, type FormEvent } from 'react'
import { Search, X } from 'lucide-react'
import {
  GENRES, artistTracks, playlistTracks, searchArtists, searchPlaylists, searchTracks, trending, trendingPlaylists, underground,
  type Artist, type Collection, type Track,
} from '../data/audius'
import { legendaryShows, searchShows, showTracks, type Show } from '../data/archive'
import { searchVideos, trendingVideos, YouTubeError } from '../data/youtube'
import { YouTubeSetup } from './YouTubeSetup'
import { useAsync, useLibrary } from '../library/context'
import { CollectionRow, DrillHead, Loadable, Section, TrackGrid, TrackRows } from './lists'

type View =
  | { kind: 'home' }
  | { kind: 'genre'; genre: string }
  | { kind: 'artist'; artist: Artist }
  | { kind: 'playlist'; pl: Collection }
  | { kind: 'show'; show: Show }

type Props = { onClose: () => void }

export function Browse({ onClose }: Props) {
  const lib = useLibrary()
  const [stack, setStack] = useState<View[]>([{ kind: 'home' }])
  const [query, setQuery] = useState('')
  const [q, setQ] = useState('') // debounced
  const searchRef = useRef<HTMLInputElement>(null)
  const scroller = useRef<HTMLDivElement>(null)
  const view = stack[stack.length - 1]

  useEffect(() => {
    searchRef.current?.focus()
  }, [])
  useEffect(() => {
    const id = window.setTimeout(() => setQ(query.trim()), 320)
    return () => window.clearTimeout(id)
  }, [query])
  useEffect(() => {
    scroller.current?.scrollTo({ top: 0 })
  }, [stack.length, q])

  const open = (v: View) => setStack([...stack, v])
  const back = () => setStack(stack.length > 1 ? stack.slice(0, -1) : stack)
  const submit = (e: FormEvent) => {
    e.preventDefault()
    const v = query.trim()
    if (v) {
      setQ(v)
      lib.addRecent(v)
    }
  }
  const searchFor = (v: string) => {
    setQuery(v)
    setQ(v)
    setStack([{ kind: 'home' }])
  }
  const searching = view.kind === 'home' && q.length > 0

  return (
    <section className="panel browse" aria-labelledby="browse-title">
      <header className="panel-head">
        <h2 id="browse-title">Find music</h2>
        <button className="icon-btn" onClick={onClose} aria-label="Close music finder">
          <X size={20} strokeWidth={1.75} />
        </button>
      </header>
      <form className="search" onSubmit={submit} role="search">
        <Search size={18} strokeWidth={1.75} aria-hidden="true" />
        <input
          ref={searchRef}
          type="search"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value)
            if (stack.length > 1) setStack([{ kind: 'home' }])
          }}
          placeholder="Any song or artist"
          aria-label="Search songs, artists, playlists and live shows"
        />
        {query && (
          <button type="button" className="search-clear" onClick={() => searchFor('')} aria-label="Clear search">
            <X size={16} strokeWidth={2} />
          </button>
        )}
      </form>

      <div className="grid-scroll" ref={scroller}>
        {view.kind === 'home' && !searching && <Home onSearch={searchFor} open={open} />}
        {searching && <Results q={q} open={open} />}
        {view.kind === 'genre' && <GenreView genre={view.genre} onBack={back} />}
        {view.kind === 'artist' && <ArtistView artist={view.artist} onBack={back} />}
        {view.kind === 'playlist' && <PlaylistView pl={view.pl} onBack={back} />}
        {view.kind === 'show' && <ShowView show={view.show} onBack={back} />}
        {view.kind === 'home' && !searching && lib.ytKey && (
          <p className="credit">
            Official songs come from YouTube and play in YouTube's own player with their original sound.{' '}
            <button className="text-btn" onClick={() => lib.setYtKey(null)}>
              Disconnect YouTube
            </button>
          </p>
        )}
        <p className="credit">
          Studio tracks stream free from <a href="https://audius.co" target="_blank" rel="noreferrer">Audius</a>. Live recordings come from the{' '}
          <a href="https://archive.org/details/etree" target="_blank" rel="noreferrer">Internet Archive's Live Music Archive</a>.
        </p>
      </div>
    </section>
  )
}

function useMore(n: number) {
  const [all, setAll] = useState(false)
  return { all, toggle: () => setAll(!all), take: <T,>(xs: T[]) => (all ? xs : xs.slice(0, n)) }
}

function Home({ onSearch, open }: { onSearch: (q: string) => void; open: (v: View) => void }) {
  const lib = useLibrary()
  const top = useAsync((s) => trending(null, s), [])
  const pls = useAsync((s) => trendingPlaylists(s), [])
  const under = useAsync((s) => underground(s), [])
  const live = useAsync((s) => legendaryShows(s), [])
  const yt = useAsync(lib.ytKey ? (s) => trendingVideos(lib.ytKey!, s) : null, [lib.ytKey])
  const more = useMore(9)
  const moreYt = useMore(8)

  return (
    <>
      {lib.ytKey ? (
        <Section
          title="Trending official songs"
          action={
            yt.data && yt.data.length > 8 ? (
              <button className="text-btn" onClick={moreYt.toggle}>
                {moreYt.all ? 'Show less' : `Show all ${yt.data.length}`}
              </button>
            ) : null
          }
        >
          <Loadable a={yt} empty="YouTube has no trending music for your region right now.">
            {(d) => <TrackRows list={moreYt.take(d)} />}
          </Loadable>
        </Section>
      ) : (
        <YouTubeSetup compact />
      )}

      {lib.recent.length > 0 && (
        <Section
          title="Recent searches"
          action={
            <button className="text-btn" onClick={lib.clearRecent}>
              Clear
            </button>
          }
        >
          <div className="chips chips-wrap">
            {lib.recent.map((r) => (
              <button key={r} className="chip" onClick={() => onSearch(r)}>
                {r}
              </button>
            ))}
          </div>
        </Section>
      )}

      <Section title="Browse by genre">
        <div className="chips">
          {GENRES.map((g) => (
            <button key={g} className="chip" onClick={() => open({ kind: 'genre', genre: g })}>
              {g}
            </button>
          ))}
        </div>
      </Section>

      <Section
        title="Trending on Audius"
        action={
          top.data && top.data.length > 9 ? (
            <button className="text-btn" onClick={more.toggle}>
              {more.all ? 'Show less' : `Show all ${top.data.length}`}
            </button>
          ) : null
        }
      >
        <Loadable a={top} empty="Nothing is trending right now." skeleton="grid">
          {(d) => <TrackGrid list={more.take(d)} />}
        </Loadable>
      </Section>

      <Section title="Trending playlists">
        <Loadable a={pls} empty="No trending playlists right now.">
          {(d) => (
            <ul className="rows">
              {d.slice(0, 6).map((p) => (
                <CollectionRow key={p.id} art={p.art} title={p.name} meta={`${p.owner} · ${p.count} songs`} onOpen={() => open({ kind: 'playlist', pl: p })} />
              ))}
            </ul>
          )}
        </Loadable>
      </Section>

      <Section title="Rising underground">
        <Loadable a={under} empty="Nothing rising right now." skeleton="grid">
          {(d) => <TrackGrid list={d.slice(0, 6)} />}
        </Loadable>
      </Section>

      <Section title="Legendary live shows">
        <Loadable a={live} empty="Couldn't find live shows right now.">
          {(d) => (
            <ul className="rows">
              {d.slice(0, 6).map((s) => (
                <CollectionRow key={s.id} art={s.art} title={s.artist} meta={[s.venue, s.date].filter(Boolean).join(' · ')} badge="Live" onOpen={() => open({ kind: 'show', show: s })} />
              ))}
            </ul>
          )}
        </Loadable>
      </Section>
    </>
  )
}

function Results({ q, open }: { q: string; open: (v: View) => void }) {
  const lib = useLibrary()
  // YouTube searches cost quota: wait for typing to settle a little longer, and cache.
  const [ytQ, setYtQ] = useState(q)
  useEffect(() => {
    const id = window.setTimeout(() => setYtQ(q), 600)
    return () => window.clearTimeout(id)
  }, [q])
  const [ytErr, setYtErr] = useState<string | null>(null)
  const yt = useAsync(
    lib.ytKey && ytQ
      ? (s) =>
          searchVideos(ytQ, lib.ytKey!, s).catch((e) => {
            if (e instanceof YouTubeError) setYtErr(e.message)
            throw e
          })
      : null,
    [ytQ, lib.ytKey],
  )
  useEffect(() => setYtErr(null), [ytQ])
  const artists = useAsync((s) => searchArtists(q, s), [q])
  const first = useAsync((s) => searchTracks(q, 0, s), [q])
  const shows = useAsync((s) => searchShows(q, s), [q])
  const pls = useAsync((s) => searchPlaylists(q, s), [q])
  const [extra, setExtra] = useState<Track[]>([])
  const [paging, setPaging] = useState<'idle' | 'loading' | 'done' | 'error'>('idle')

  useEffect(() => {
    setExtra([])
    setPaging('idle')
  }, [q])

  const songs = [...(first.data ?? []), ...extra.filter((t) => !(first.data ?? []).some((x) => x.id === t.id))]
  const loadMore = () => {
    setPaging('loading')
    searchTracks(q, songs.length)
      .then((more) => {
        setExtra((e) => [...e, ...more])
        setPaging(more.length < 20 ? 'done' : 'idle')
      })
      .catch(() => setPaging('error'))
  }

  const allEmpty =
    [artists, first, shows, pls].every((a) => a.status !== 'loading') &&
    (!lib.ytKey || yt.status === 'ready') &&
    !yt.data?.length && !artists.data?.length && !first.data?.length && !shows.data?.length && !pls.data?.length

  if (allEmpty) {
    return (
      <div className="empty">
        <p>Nothing matched “{q}”. Check the spelling, or try just the artist's name.</p>
        {!lib.ytKey && <YouTubeSetup compact />}
      </div>
    )
  }

  return (
    <>
      {lib.ytKey ? (
        <Section title="Official songs">
          {yt.status === 'error' ? (
            <p className="empty">{ytErr ?? "Couldn't search YouTube right now."}</p>
          ) : (
            <Loadable a={yt} empty={`No official songs found for “${ytQ}”.`}>
              {(d) => <TrackRows list={d} />}
            </Loadable>
          )}
        </Section>
      ) : (
        <YouTubeSetup compact />
      )}

      {(artists.status === 'loading' || (artists.data?.length ?? 0) > 0) && (
        <Section title="Artists on Audius">
          <Loadable a={artists} empty="">
            {(d) => (
              <ul className="artists">
                {d.map((a) => (
                  <li key={a.id}>
                    <button className="artist" onClick={() => open({ kind: 'artist', artist: a })}>
                      <span className="artist-face">{a.avatar ? <img src={a.avatar} alt="" loading="lazy" /> : null}</span>
                      <span className="artist-name">{a.name}</span>
                      <span className="artist-meta">{a.tracks} songs</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </Loadable>
        </Section>
      )}

      <Section title="Independent artists on Audius">
        <Loadable a={first} empty="No Audius songs for this search.">
          {() => (
            <>
              <TrackRows list={songs} />
              {paging !== 'done' && songs.length >= 20 && (
                <button className="pill pill-quiet more" onClick={loadMore} disabled={paging === 'loading'}>
                  {paging === 'loading' ? 'Loading…' : paging === 'error' ? "Couldn't load more. Try again" : 'More songs'}
                </button>
              )}
            </>
          )}
        </Loadable>
      </Section>

      {(shows.status === 'loading' || (shows.data?.length ?? 0) > 0) && (
        <Section title="Live recordings">
          <Loadable a={shows} empty="">
            {(d) => (
              <ul className="rows">
                {d.map((s) => (
                  <CollectionRow key={s.id} art={s.art} title={s.artist} meta={[s.venue, s.place, s.date].filter(Boolean).join(' · ')} badge="Live" onOpen={() => open({ kind: 'show', show: s })} />
                ))}
              </ul>
            )}
          </Loadable>
        </Section>
      )}

      {(pls.status === 'loading' || (pls.data?.length ?? 0) > 0) && (
        <Section title="Playlists">
          <Loadable a={pls} empty="">
            {(d) => (
              <ul className="rows">
                {d.map((p) => (
                  <CollectionRow key={p.id} art={p.art} title={p.name} meta={`${p.owner} · ${p.count} songs`} onOpen={() => open({ kind: 'playlist', pl: p })} />
                ))}
              </ul>
            )}
          </Loadable>
        </Section>
      )}
    </>
  )
}

function GenreView({ genre, onBack }: { genre: string; onBack: () => void }) {
  const a = useAsync((s) => trending(genre, s), [genre])
  return (
    <>
      <DrillHead title={genre} meta="Trending this week" onBack={onBack} list={a.data} />
      <Loadable a={a} empty={`No ${genre} songs are trending this week. Try another genre.`} skeleton="grid">
        {(d) => <TrackGrid list={d} />}
      </Loadable>
    </>
  )
}

function ArtistView({ artist, onBack }: { artist: Artist; onBack: () => void }) {
  const a = useAsync((s) => artistTracks(artist.id, s), [artist.id])
  return (
    <>
      <DrillHead title={artist.name} meta={`@${artist.handle} · ${artist.followers.toLocaleString()} followers`} onBack={onBack} list={a.data} />
      <Loadable a={a} empty="This artist has no streamable songs.">
        {(d) => <TrackRows list={d} />}
      </Loadable>
    </>
  )
}

function PlaylistView({ pl, onBack }: { pl: Collection; onBack: () => void }) {
  const a = useAsync((s) => playlistTracks(pl.id, s), [pl.id])
  return (
    <>
      <DrillHead title={pl.name} meta={`Playlist by ${pl.owner}`} onBack={onBack} list={a.data} />
      <Loadable a={a} empty="This playlist has no streamable songs.">
        {(d) => <TrackRows list={d} />}
      </Loadable>
    </>
  )
}

function ShowView({ show, onBack }: { show: Show; onBack: () => void }) {
  const a = useAsync((s) => showTracks(show.id, s).then((r) => r.tracks), [show.id])
  return (
    <>
      <DrillHead title={show.artist} meta={[show.venue, show.place, show.date].filter(Boolean).join(' · ') + ' · Live recording'} onBack={onBack} list={a.data} />
      <Loadable a={a} empty="This recording has no playable files.">
        {(d) => <TrackRows list={d} />}
      </Loadable>
    </>
  )
}
