import { useState, type FormEvent } from 'react'
import { Heart, Plus, X } from 'lucide-react'
import { useLibrary } from '../library/context'
import { CollectionRow, DrillHead, Section, TrackRows } from './lists'

type View = { kind: 'home' } | { kind: 'liked' } | { kind: 'playlist'; id: string }

export function Library({ onClose }: { onClose: () => void }) {
  const [view, setView] = useState<View>({ kind: 'home' })
  return (
    <section className="panel library" aria-labelledby="library-title">
      <header className="panel-head">
        <h2 id="library-title">Library</h2>
        <button className="icon-btn" onClick={onClose} aria-label="Close library">
          <X size={20} strokeWidth={1.75} />
        </button>
      </header>
      <div className="grid-scroll">
        {view.kind === 'home' && <LibraryHome open={setView} />}
        {view.kind === 'liked' && <Liked onBack={() => setView({ kind: 'home' })} />}
        {view.kind === 'playlist' && <PlaylistDetail id={view.id} onBack={() => setView({ kind: 'home' })} />}
      </div>
    </section>
  )
}

function LibraryHome({ open }: { open: (v: View) => void }) {
  const lib = useLibrary()
  const [creating, setCreating] = useState(false)
  const [name, setName] = useState('')
  const likedCount = Object.keys(lib.liked).length

  const create = (e: FormEvent) => {
    e.preventDefault()
    const id = lib.createPlaylist(name.trim() || `My playlist ${lib.playlists.length + 1}`)
    setName('')
    setCreating(false)
    open({ kind: 'playlist', id })
  }

  return (
    <>
      <ul className="rows">
        <li className="row">
          <button className="row-main" onClick={() => open({ kind: 'liked' })}>
            <span className="row-art liked-art" aria-hidden="true">
              <Heart size={22} strokeWidth={2} fill="currentColor" />
            </span>
            <span className="row-text">
              <span className="row-title">Liked songs</span>
              <span className="row-meta">{likedCount === 1 ? '1 song' : `${likedCount} songs`}</span>
            </span>
          </button>
        </li>
      </ul>

      <Section
        title="Your playlists"
        action={
          !creating && (
            <button className="pill pill-quiet" onClick={() => setCreating(true)}>
              <Plus size={16} strokeWidth={2} aria-hidden="true" /> New playlist
            </button>
          )
        }
      >
        {creating && (
          <form className="inline-form" onSubmit={create}>
            <input autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="Playlist name" aria-label="Playlist name" maxLength={60} />
            <button className="pill pill-primary" type="submit">
              Create
            </button>
            <button className="pill pill-quiet" type="button" onClick={() => setCreating(false)}>
              Cancel
            </button>
          </form>
        )}
        {lib.playlists.length === 0 && !creating ? (
          <p className="empty">No playlists yet. Make one here, or use “Add to playlist” on any song.</p>
        ) : (
          <ul className="rows">
            {lib.playlists.map((p) => (
              <CollectionRow
                key={p.id}
                art={p.tracks.find((t) => t.art)?.art ?? null}
                title={p.name}
                meta={p.tracks.length === 1 ? '1 song' : `${p.tracks.length} songs`}
                onOpen={() => open({ kind: 'playlist', id: p.id })}
                list
              />
            ))}
          </ul>
        )}
      </Section>
    </>
  )
}

function Liked({ onBack }: { onBack: () => void }) {
  const lib = useLibrary()
  const list = Object.values(lib.liked).reverse() // newest first
  return (
    <>
      <DrillHead title="Liked songs" meta={list.length === 1 ? '1 song' : `${list.length} songs`} onBack={onBack} list={list} />
      {list.length === 0 ? (
        <p className="empty">Songs you like show up here. Tap the heart on anything playing, or on any song in Find music.</p>
      ) : (
        <TrackRows list={list} />
      )}
    </>
  )
}

function PlaylistDetail({ id, onBack }: { id: string; onBack: () => void }) {
  const lib = useLibrary()
  const p = lib.playlists.find((x) => x.id === id)
  const [renaming, setRenaming] = useState(false)
  const [name, setName] = useState(p?.name ?? '')
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [editing, setEditing] = useState(false)

  if (!p) {
    return (
      <div className="empty">
        <p>This playlist was deleted.</p>
        <button className="pill pill-quiet" onClick={onBack}>
          Back to Library
        </button>
      </div>
    )
  }

  const rename = (e: FormEvent) => {
    e.preventDefault()
    if (name.trim()) lib.renamePlaylist(p.id, name.trim())
    setRenaming(false)
  }

  return (
    <>
      <DrillHead title={p.name} meta={p.tracks.length === 1 ? '1 song' : `${p.tracks.length} songs`} onBack={onBack} list={p.tracks}>
        <button className="pill pill-quiet" onClick={() => setRenaming(!renaming)} aria-expanded={renaming}>
          Rename
        </button>
        {p.tracks.length > 1 && (
          <button className="pill pill-quiet" aria-pressed={editing} onClick={() => setEditing(!editing)}>
            {editing ? 'Done' : 'Reorder'}
          </button>
        )}
        <button className="pill pill-quiet" onClick={() => setConfirmDelete(true)}>
          Delete
        </button>
      </DrillHead>

      {renaming && (
        <form className="inline-form" onSubmit={rename}>
          <input autoFocus value={name} onChange={(e) => setName(e.target.value)} aria-label="Playlist name" maxLength={60} />
          <button className="pill pill-primary" type="submit">
            Save
          </button>
        </form>
      )}
      {confirmDelete && (
        <div className="confirm" role="alert">
          <p>Delete “{p.name}”? This can't be undone.</p>
          <div className="confirm-actions">
            <button
              className="pill pill-danger"
              onClick={() => {
                lib.deletePlaylist(p.id)
                onBack()
              }}
            >
              Delete playlist
            </button>
            <button className="pill pill-quiet" onClick={() => setConfirmDelete(false)}>
              Keep it
            </button>
          </div>
        </div>
      )}

      {p.tracks.length === 0 ? (
        <p className="empty">This playlist is empty. Use “Add to playlist” on any song to put it here.</p>
      ) : (
        <TrackRows
          list={p.tracks}
          extras={(i) =>
            editing
              ? { onUp: () => lib.movePlaylistTrack(p.id, i, i - 1), onDown: () => lib.movePlaylistTrack(p.id, i, i + 1) }
              : { onRemove: () => lib.removeFromPlaylist(p.id, p.tracks[i].id) }
          }
        />
      )}
    </>
  )
}
