import { Heart, Pause, Play, SkipBack, SkipForward, LoaderCircle } from 'lucide-react'
import type { Track } from '../data/audius'
import { AddToPlaylist } from './AddToPlaylist'

export type Tempo = 'slowed' | 'normal' | 'sped'
export const TEMPO_RATE: Record<Tempo, number> = { slowed: 0.85, normal: 1, sped: 1.15 }

type Props = {
  track: Track | null
  playing: boolean
  loading: boolean
  time: number
  duration: number
  tempo: Tempo
  loved: boolean
  compare: boolean
  canCompare: boolean
  onToggle: () => void
  onPrev: () => void
  onNext: () => void
  onSeek: (t: number) => void
  onTempo: (t: Tempo) => void
  onLove: () => void
  onCompare: (on: boolean) => void
}

const fmt = (s: number) => {
  if (!Number.isFinite(s) || s < 0) s = 0
  const m = Math.floor(s / 60)
  return `${m}:${String(Math.floor(s % 60)).padStart(2, '0')}`
}

/** The song's billing, projected onto the wall under the dish: title at poster scale, controls as projector linework. */
export function NowPlaying(p: Props) {
  const t = p.track
  const dur = p.duration || t?.duration || 0
  const pct = dur ? (p.time / dur) * 100 : 0
  return (
    <section className="deck" aria-label="Now playing">
      <div className="deck-bill">
        <p className="deck-title" title={t?.title}>
          {t ? t.title : 'Finding music…'}
        </p>
        <p className="deck-artist">
          {t ? (
            <a href={t.permalink} target="_blank" rel="noreferrer">
              {t.artist}
            </a>
          ) : (
            'Trending on Audius'
          )}
          {t?.subtitle ? <span className="deck-genre"> · {t.subtitle}</span> : t?.genre && t.genre !== 'Unknown' ? <span className="deck-genre"> · {t.genre}</span> : null}
        </p>
      </div>

      <div className="deck-actions">
        <button className="pill pill-quiet love" onClick={p.onLove} aria-pressed={p.loved} disabled={!t}>
          <Heart size={18} strokeWidth={1.75} fill={p.loved ? 'currentColor' : 'none'} aria-hidden="true" />
          <span>{p.loved ? 'Liked' : 'Like'}</span>
        </button>
        <AddToPlaylist
          track={t}
          className="pill pill-quiet add"
          label={
            <>
              <span className="long">Add to playlist</span>
              <span className="short">Add</span>
            </>
          }
        />
      </div>

      <div className="deck-transport">
        <button className="icon-btn" onClick={p.onPrev} aria-label="Previous song" disabled={!t}>
          <SkipBack size={22} strokeWidth={1.75} />
        </button>
        <button className="play" onClick={p.onToggle} aria-label={p.playing ? 'Pause' : 'Play'} disabled={!t}>
          {p.loading ? (
            <LoaderCircle className="spin" size={28} strokeWidth={2} />
          ) : p.playing ? (
            <Pause size={28} strokeWidth={2} fill="currentColor" />
          ) : (
            <Play size={28} strokeWidth={2} fill="currentColor" className="nudge" />
          )}
        </button>
        <button className="icon-btn" onClick={p.onNext} aria-label="Next song" disabled={!t}>
          <SkipForward size={22} strokeWidth={1.75} />
        </button>
      </div>

      <div className="scrub">
        <span className="time">{fmt(p.time)}</span>
        <input
          type="range"
          min={0}
          max={dur || 1}
          step={0.5}
          value={Math.min(p.time, dur || 1)}
          onChange={(e) => p.onSeek(Number(e.target.value))}
          aria-label="Seek"
          aria-valuetext={`${fmt(p.time)} of ${fmt(dur)}`}
          style={{ ['--pct' as string]: `${pct}%` }}
          disabled={!t}
        />
        <span className="time">{fmt(dur)}</span>
      </div>

      <div className="deck-feel">
        <div className="segmented" role="radiogroup" aria-label="Tempo">
          {(['slowed', 'normal', 'sped'] as Tempo[]).map((k) => (
            <button key={k} role="radio" aria-checked={p.tempo === k} onClick={() => p.onTempo(k)}>
              {k === 'slowed' ? 'Slowed' : k === 'normal' ? 'Normal' : 'Sped up'}
            </button>
          ))}
        </div>
        {p.canCompare && (
          <button className="pill pill-quiet compare" aria-pressed={p.compare} onClick={() => p.onCompare(!p.compare)}>
            {p.compare ? 'Hearing the original' : 'Hear the original'}
          </button>
        )}
      </div>
    </section>
  )
}
