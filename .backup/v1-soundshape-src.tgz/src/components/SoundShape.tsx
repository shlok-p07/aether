import { useEffect, useLayoutEffect, useRef, useState, type KeyboardEvent, type PointerEvent } from 'react'
import { AXES, AXIS_INFO, clamp01, type Axis, type Shape } from '../audio/shape'
import { bus } from '../visual/bus'

type Props = {
  shape: Shape
  onChange: (s: Shape) => void
  onCommit: () => void
}

const INNER = 0.2
const OUTER = 0.9
const angleOf = (i: number) => -Math.PI / 2 + (i * Math.PI * 2) / AXES.length

export function SoundShape({ shape, onChange, onCommit }: Props) {
  const wrap = useRef<HTMLDivElement>(null)
  const breath = useRef<SVGGElement>(null)
  const [box, setBox] = useState({ w: 600, h: 500 })
  const [drag, setDrag] = useState<Axis | null>(null)
  const shapeRef = useRef(shape)
  shapeRef.current = shape

  useLayoutEffect(() => {
    const el = wrap.current
    if (!el) return
    const measure = () => {
      const r = el.getBoundingClientRect()
      setBox({ w: r.width, h: r.height })
    }
    measure()
    const ro = new ResizeObserver(measure)
    ro.observe(el)
    window.addEventListener('scroll', measure, true)
    return () => {
      ro.disconnect()
      window.removeEventListener('scroll', measure, true)
    }
  }, [])

  const narrow = box.w < 520
  // A short stage (a panel is open on a phone) drops the labels and keeps just the dish and points.
  const compact = box.h < 280
  const labelW = compact ? 20 : narrow ? 64 : 104
  const R = Math.max(56, Math.min(box.w / 2 - labelW, box.h / 2 - (compact ? 14 : narrow ? 40 : 48)))
  const cx = box.w / 2
  const cy = box.h / 2

  // Each frame: tell the light show where the dish is (layout can move it at any time),
  // and let the shape breathe with the low end.
  useEffect(() => {
    let raf = 0
    const tick = () => {
      const el = wrap.current
      if (el) {
        const r = el.getBoundingClientRect()
        bus.dish.x = r.left + cx
        bus.dish.y = r.top + cy
        bus.dish.r = R
      }
      const g = breath.current
      if (g) {
        const s = bus.calm ? 1 : 1 + bus.bands.low * 0.045
        g.setAttribute('transform', `translate(${cx} ${cy}) scale(${s.toFixed(4)})`)
      }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [cx, cy, R])

  const radiusFor = (v: number) => R * (INNER + (OUTER - INNER) * v)
  const point = (i: number, v: number) => {
    const a = angleOf(i)
    const rr = radiusFor(v)
    return [Math.cos(a) * rr, Math.sin(a) * rr] as const
  }
  const ring = (frac: number) =>
    AXES.map((_, i) => {
      const a = angleOf(i)
      return `${(Math.cos(a) * R * frac).toFixed(1)},${(Math.sin(a) * R * frac).toFixed(1)}`
    }).join(' ')

  const valueFromPointer = (i: number, e: PointerEvent) => {
    const el = wrap.current!
    const rect = el.getBoundingClientRect()
    const x = e.clientX - rect.left - cx
    const y = e.clientY - rect.top - cy
    const a = angleOf(i)
    const along = x * Math.cos(a) + y * Math.sin(a)
    return clamp01((along / R - INNER) / (OUTER - INNER))
  }

  const setAxis = (axis: Axis, v: number) => {
    const next = { ...shapeRef.current, [axis]: Math.round(v * 100) / 100 }
    onChange(next)
  }

  const onDown = (axis: Axis, i: number) => (e: PointerEvent<SVGGElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId)
    setDrag(axis)
    bus.push.active = true
    bus.push.x = e.clientX
    bus.push.y = e.clientY
    bus.push.amt = 1
    setAxis(axis, valueFromPointer(i, e))
  }
  const onMove = (axis: Axis, i: number) => (e: PointerEvent<SVGGElement>) => {
    if (drag !== axis) return
    bus.push.x = e.clientX
    bus.push.y = e.clientY
    bus.push.amt = 1
    setAxis(axis, valueFromPointer(i, e))
  }
  const onUp = (e: PointerEvent<SVGGElement>) => {
    if (!drag) return
    e.currentTarget.releasePointerCapture(e.pointerId)
    setDrag(null)
    bus.push.active = false
    onCommit()
  }

  const onKey = (axis: Axis) => (e: KeyboardEvent) => {
    const v = shapeRef.current[axis]
    const step = { ArrowUp: 0.05, ArrowRight: 0.05, ArrowDown: -0.05, ArrowLeft: -0.05, PageUp: 0.2, PageDown: -0.2 } as Record<string, number>
    let next: number | null = null
    if (e.key in step) next = v + step[e.key]
    else if (e.key === 'Home') next = 0
    else if (e.key === 'End') next = 1
    if (next === null) return
    e.preventDefault()
    setAxis(axis, clamp01(next))
  }

  const poly = AXES.map((a, i) => point(i, shape[a]).map((n) => n.toFixed(1)).join(',')).join(' ')

  return (
    <div ref={wrap} className="shape-stage">
      <svg width={box.w} height={box.h} className="shape-svg" role="group" aria-label="Sound Shape: drag a point outward to add more of it">
        <g ref={breath} transform={`translate(${cx} ${cy})`}>
          <polygon points={ring(OUTER)} className="ghost" />
          <polygon points={ring(INNER)} className="ghost ghost-inner" />
          {AXES.map((_, i) => {
            const a = angleOf(i)
            return (
              <line
                key={i}
                className="spoke"
                x1={Math.cos(a) * R * INNER}
                y1={Math.sin(a) * R * INNER}
                x2={Math.cos(a) * (R + 10)}
                y2={Math.sin(a) * (R + 10)}
              />
            )
          })}
          <polygon points={poly} className="shape-fill" />
          {AXES.map((axis, i) => {
            const [x, y] = point(i, shape[axis])
            const a = angleOf(i)
            const info = AXIS_INFO[axis]
            const lx = Math.cos(a) * (R + 20)
            const ly = Math.sin(a) * (R + 20)
            const c = Math.cos(a)
            const anchor = c > 0.3 ? 'start' : c < -0.3 ? 'end' : 'middle'
            const dy = Math.sin(a) < -0.6 ? -22 : Math.sin(a) > 0.6 ? 14 : -4
            return (
              <g key={axis}>
                <line className="leader" x1={x} y1={y} x2={Math.cos(a) * (R + 10)} y2={Math.sin(a) * (R + 10)} />
                {!compact && (
                  <>
                    <text className="axis-label" x={lx} y={ly + dy} textAnchor={anchor}>
                      {info.label}
                    </text>
                    <text className="axis-value" x={lx} y={ly + dy + 17} textAnchor={anchor}>
                      {info.readout(shape[axis])}
                    </text>
                  </>
                )}
                <g
                  className={`knob${drag === axis ? ' is-dragging' : ''}`}
                  tabIndex={0}
                  role="slider"
                  aria-label={`${info.label}: ${info.hint}`}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={Math.round(shape[axis] * 100)}
                  aria-valuetext={info.readout(shape[axis])}
                  onPointerDown={onDown(axis, i)}
                  onPointerMove={onMove(axis, i)}
                  onPointerUp={onUp}
                  onPointerCancel={onUp}
                  onKeyDown={onKey(axis)}
                  onKeyUp={(e) => e.key.startsWith('Arrow') || e.key.startsWith('Page') || e.key === 'Home' || e.key === 'End' ? onCommit() : undefined}
                >
                  <title>{info.hint}</title>
                  <circle className="knob-hit" cx={x} cy={y} r={24} />
                  <circle className="knob-focus" cx={x} cy={y} r={14} />
                  <circle className="knob-dot" cx={x} cy={y} r={7} />
                </g>
              </g>
            )
          })}
        </g>
      </svg>
    </div>
  )
}
