import { useEffect, useMemo, useState } from 'react'
import { Play, X } from 'lucide-react'
import { STARTER, type Shape } from '../audio/shape'

type Choice = { id: string; label: string; detail: string; set: Partial<Shape> }
type Step = { q: string; choices: Choice[] }

const STEPS: Step[] = [
  {
    q: 'Where do you feel music most?',
    choices: [
      { id: 'chest', label: 'In my chest', detail: 'Heavy low end, drums that hit', set: { bass: 0.78, punch: 0.55, air: 0.2 } },
      { id: 'detail', label: 'In the details', detail: 'Crisp highs, every texture clear', set: { bass: 0.22, punch: 0.3, air: 0.66 } },
      { id: 'even', label: 'All of it, evenly', detail: 'Balanced, nothing sticks out', set: { bass: 0.42, punch: 0.38, air: 0.38 } },
    ],
  },
  {
    q: 'Where are you standing?',
    choices: [
      { id: 'studio', label: 'In the studio', detail: 'Dry and close, like the producer hears it', set: { room: 0.02, width: 0.18 } },
      { id: 'club', label: 'Front row at a club', detail: 'Tight room, speakers in your face', set: { room: 0.26, width: 0.42 } },
      { id: 'arena', label: 'Middle of an arena', detail: 'Big, wide and live', set: { room: 0.68, width: 0.7 } },
      { id: 'cathedral', label: 'Inside a cathedral', detail: 'Endless, dreamy tails', set: { room: 0.95, width: 0.55 } },
    ],
  },
  {
    q: 'What should it feel like?',
    choices: [
      { id: 'clean', label: 'Clean and crisp', detail: 'Exactly as mastered', set: { warmth: 0.04 } },
      { id: 'warm', label: 'Warm, like vinyl', detail: 'Soft tape saturation, rounder highs', set: { warmth: 0.6 } },
    ],
  },
  {
    q: 'Should the sound move around you?',
    choices: [
      { id: 'still', label: 'Stay put', detail: 'A fixed stereo image', set: { orbit: 0 } },
      { id: 'drift', label: 'Drift slowly', detail: 'A gentle sway, left to right', set: { orbit: 0.3 } },
      { id: 'circle', label: 'Circle my head', detail: 'The full 8D orbit', set: { orbit: 0.75 } },
    ],
  },
]

type Props = {
  start: Shape
  playing: boolean
  onPlay: () => void
  onPreview: (s: Shape) => void
  onFinish: (s: Shape) => void
  onClose: () => void
}

export function TasteTuner({ start, playing, onPlay, onPreview, onFinish, onClose }: Props) {
  const [step, setStep] = useState(0)
  const [picks, setPicks] = useState<Record<number, string>>({})

  const shapeFrom = (p: Record<number, string>) => {
    let s: Shape = { ...STARTER, orbit: start.orbit }
    STEPS.forEach((st, i) => {
      const c = st.choices.find((x) => x.id === p[i])
      if (c) s = { ...s, ...c.set }
    })
    return s
  }
  const current = useMemo(() => shapeFrom(picks), [picks]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    onPreview(current)
  }, [current]) // eslint-disable-line react-hooks/exhaustive-deps

  const st = STEPS[step]
  const picked = picks[step]
  const last = step === STEPS.length - 1

  return (
    <section className="panel tuner" aria-labelledby="tuner-title">
      <header className="panel-head">
        <h2 id="tuner-title">Tune your ear</h2>
        <button className="icon-btn" onClick={onClose} aria-label="Close without saving">
          <X size={20} strokeWidth={1.75} />
        </button>
      </header>
      <p className="panel-lede">
        Four quick picks. Each one changes the song as you choose it, so trust what you hear.
      </p>
      {!playing && (
        <button className="pill pill-quiet listen" onClick={onPlay}>
          <Play size={16} strokeWidth={2} /> Play a song to hear your picks
        </button>
      )}
      <p className="step-count">
        Question {step + 1} of {STEPS.length}
      </p>
      <ol className="steps" aria-hidden="true">
        {STEPS.map((_, i) => (
          <li key={i} className={i === step ? 'on' : picks[i] ? 'done' : ''} aria-current={i === step ? 'step' : undefined} />
        ))}
      </ol>
      <fieldset className="question" key={step}>
        <legend className="question-title">{st.q}</legend>
        <div className="choices">
          {st.choices.map((c, i) => (
            <label key={c.id} className={`choice${picked === c.id ? ' is-picked' : ''}`} style={{ animationDelay: `${i * 50}ms` }}>
              <input
                type="radio"
                name={`q${step}`}
                value={c.id}
                checked={picked === c.id}
                onChange={() => setPicks({ ...picks, [step]: c.id })}
              />
              <span className="choice-label">{c.label}</span>
              <span className="choice-detail">{c.detail}</span>
            </label>
          ))}
        </div>
      </fieldset>
      <footer className="panel-foot">
        <button className="pill pill-quiet" onClick={() => setStep(step - 1)} disabled={step === 0}>
          Back
        </button>
        {last ? (
          <button className="pill pill-primary" onClick={() => onFinish(current)} disabled={!picked}>
            Save my sound
          </button>
        ) : (
          <button className="pill pill-primary" onClick={() => setStep(step + 1)} disabled={!picked}>
            Next
          </button>
        )}
      </footer>
    </section>
  )
}
