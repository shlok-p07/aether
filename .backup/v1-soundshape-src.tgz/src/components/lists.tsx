import type { ReactNode } from 'react'
import { ArrowDown, ArrowUp, ChevronLeft, Heart, ListMusic, Mic, Play, RotateCw, X } from 'lucide-react'
import type { Track } from '../data/audius'
import { fmtTime, useLibrary, type Async } from '../library/context'
import { AddToPlaylist } from './AddToPlaylist'

export function Section({ title, action, children }: { title: string; action?: ReactNode; children: ReactNode }) {
  return (
    <section className="section">
      <div className="section-head">
        <h3 className="list-title">{title}</h3>
        {action}
      </div>
      {children}
    </section>
  )
}

/** Loading / error / empty states shared by every list. */
export function Loadable<T>({ a, empty, skeleton = 'rows', children }: { a: Async<T>; empty: string; skeleton?: 'rows' | 'grid'; children: (d: T) => ReactNode }) {
  if (a.status === 'loading' && !a.data) {
    return skeleton === 'grid' ? (
      <div className="grid" aria-busy="true" aria-label="Loading">
        {Array.from({ length: 6 }, (_, i) => (
          <div key={i} className="cell-skeleton" />
        ))}
      </div>
    ) : (
      <div className="rows" aria-busy="true" aria-label="Loading">
        {Array.from({ length: 4 }, (_, i) => (
          <div key={i} className="row-skeleton" />
        ))}
      </div>
    )
  }
  if (a.status === 'error') {
    return (
      <div className="empty">
        <p>Couldn't load this. Check your connection, then try again.</p>
        <button className="pill pill-quiet" onClick={a.retry}>
          <RotateCw size={16} strokeWidth={2} aria-hidden="true" /> Try again
        </button>
      </div>
    )
  }
  const d = a.data as T
  if (!d || (Array.isArray(d) && d.length === 0)) return <p className="empty">{empty}</p>
  return <>{children(d)}</>
}

export function LikeButton({ track }: { track: Track }) {
  const lib = useLibrary()
  const liked = !!lib.liked[track.id]
  return (
    <button
      className={`icon-btn like${liked ? ' is-liked' : ''}`}
      onClick={() => lib.toggleLike(track)}
      aria-pressed={liked}
      aria-label={liked ? `Unlike “${track.title}”` : `Like “${track.title}”`}
      title={liked ? 'Liked' : 'Like'}
    >
      <Heart size={20} strokeWidth={1.75} fill={liked ? 'currentColor' : 'none'} />
    </button>
  )
}

type RowExtras = { onRemove?: () => void; onUp?: () => void; onDown?: () => void }

export function TrackRow({ list, index, extras }: { list: Track[]; index: number; extras?: RowExtras }) {
  const lib = useLibrary()
  const t = list[index]
  const current = t.id === lib.currentId
  return (
    <li className={`row${current ? ' is-current' : ''}`}>
      <button className="row-main" onClick={() => lib.play(list, index)} aria-label={`Play “${t.title}” by ${t.artist}`}>
        <RowArt art={t.art} live={t.source === 'archive'} />
        <span className="row-text">
          <span className="row-title">{t.title}</span>
          <span className="row-meta">
            {current ? <span className="now">Playing now · </span> : null}
            {t.subtitle && t.source !== 'youtube' ? `${t.artist} · ${t.subtitle}` : t.artist}
            {t.source === 'archive' ? <span className="badge">Live</span> : t.source === 'youtube' ? <span className="badge badge-yt">YouTube</span> : null}
          </span>
        </span>
        <span className="row-time">{fmtTime(t.duration)}</span>
      </button>
      {extras?.onUp && (
        <button className="icon-btn" onClick={extras.onUp} aria-label={`Move “${t.title}” up`} disabled={index === 0}>
          <ArrowUp size={18} strokeWidth={1.75} />
        </button>
      )}
      {extras?.onDown && (
        <button className="icon-btn" onClick={extras.onDown} aria-label={`Move “${t.title}” down`} disabled={index === list.length - 1}>
          <ArrowDown size={18} strokeWidth={1.75} />
        </button>
      )}
      {extras?.onRemove ? (
        <button className="icon-btn" onClick={extras.onRemove} aria-label={`Remove “${t.title}” from this playlist`} title="Remove">
          <X size={18} strokeWidth={1.75} />
        </button>
      ) : (
        <>
          <LikeButton track={t} />
          <AddToPlaylist track={t} />
        </>
      )}
    </li>
  )
}

export function TrackRows({ list, extras }: { list: Track[]; extras?: (i: number) => RowExtras }) {
  return (
    <ul className="rows">
      {list.map((t, i) => (
        <TrackRow key={`${t.id}-${i}`} list={list} index={i} extras={extras?.(i)} />
      ))}
    </ul>
  )
}

/** Cover art, or for live recordings (which have none) a stage-light tile. */
function RowArt({ art, live, round, list }: { art: string | null; live?: boolean; round?: boolean; list?: boolean }) {
  if (!art && list) {
    return (
      <span className="row-art is-list" aria-hidden="true">
        <ListMusic size={20} strokeWidth={1.75} />
      </span>
    )
  }
  if (!art && live) {
    return (
      <span className="row-art is-live" aria-hidden="true">
        <Mic size={20} strokeWidth={1.75} />
      </span>
    )
  }
  return <span className={`row-art${round ? ' is-round' : ''}`}>{art ? <img src={art} alt="" loading="lazy" /> : null}</span>
}

/** The edge-to-edge cover grid: browsing, not managing. */
export function TrackGrid({ list }: { list: Track[] }) {
  const lib = useLibrary()
  return (
    <ul className="grid">
      {list.map((t, i) => (
        <li key={t.id}>
          <button className={`cell${t.id === lib.currentId ? ' is-current' : ''}`} onClick={() => lib.play(list, i)}>
            <span className="cover">
              {t.art ? <img src={t.art} alt="" loading="lazy" /> : <span className="cover-blank" />}
              {lib.liked[t.id] && (
                <svg className="circled" viewBox="0 0 100 100" aria-hidden="true">
                  <path d="M50 6 C78 4 96 24 94 52 C92 80 70 96 46 94 C20 92 5 72 7 48 C9 24 28 9 56 9" />
                </svg>
              )}
            </span>
            <span className="cell-title">{t.title}</span>
            <span className="cell-meta">
              {t.id === lib.currentId ? 'Playing now' : t.artist}
              {lib.liked[t.id] && <span className="sr-only">, liked</span>}
            </span>
          </button>
        </li>
      ))}
    </ul>
  )
}

export function CollectionRow({ art, title, meta, onOpen, round, badge, list }: { art: string | null; title: string; meta: string; onOpen: () => void; round?: boolean; badge?: string; list?: boolean }) {
  return (
    <li className="row">
      <button className="row-main" onClick={onOpen}>
        <RowArt art={art} live={badge === 'Live'} round={round} list={list} />
        <span className="row-text">
          <span className="row-title">{title}</span>
          <span className="row-meta">
            {meta}
            {badge ? <span className="badge">{badge}</span> : null}
          </span>
        </span>
      </button>
    </li>
  )
}

/** Header for a drilled-in view (artist, playlist, show) with Back and Play all. */
export function DrillHead({ title, meta, onBack, list, children }: { title: string; meta?: string; onBack: () => void; list: Track[] | null; children?: ReactNode }) {
  const lib = useLibrary()
  return (
    <div className="drill-head">
      <button className="text-btn back" onClick={onBack}>
        <ChevronLeft size={18} strokeWidth={2} aria-hidden="true" /> Back
      </button>
      <h3 className="drill-title">{title}</h3>
      {meta ? <p className="drill-meta">{meta}</p> : null}
      <div className="drill-actions">
        <button className="pill pill-primary" onClick={() => list && list.length && lib.play(list, 0)} disabled={!list || list.length === 0}>
          <Play size={16} strokeWidth={2} fill="currentColor" aria-hidden="true" /> Play all
        </button>
        {children}
      </div>
    </div>
  )
}
