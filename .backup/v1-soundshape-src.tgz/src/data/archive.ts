import type { Track } from './audius'

/**
 * The Internet Archive's Live Music Archive: concert recordings that artists allow to be shared.
 * Free, legal, and it fits Aether's "make it feel live" promise better than anything.
 */

export type Show = {
  id: string
  title: string
  artist: string
  date: string
  venue: string
  place: string
  art: null
}

type RawDoc = { identifier: string; title?: string; creator?: string | string[]; date?: string; venue?: string; coverage?: string }
type RawFile = { name: string; title?: string; track?: string; length?: string; format?: string; creator?: string }
type RawMeta = { metadata?: { creator?: string | string[]; date?: string; venue?: string; coverage?: string; title?: string }; files?: RawFile[] }

const first = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? ''

function clean(q: string) {
  return q.replace(/[^\p{L}\p{N}\s'&-]/gu, ' ').replace(/\s+/g, ' ').trim()
}

async function find(query: string, rows: number, signal?: AbortSignal): Promise<Show[]> {
  const params = new URLSearchParams({ q: query, rows: String(rows), output: 'json' })
  for (const f of ['identifier', 'title', 'creator', 'date', 'venue', 'coverage']) params.append('fl[]', f)
  params.append('sort[]', 'downloads desc')
  const res = await fetch(`https://archive.org/advancedsearch.php?${params}`, { signal })
  if (!res.ok) throw new Error(`Live Archive answered ${res.status}`)
  const body = (await res.json()) as { response?: { docs?: RawDoc[] } }
  return (body.response?.docs ?? []).map((d) => ({
    id: d.identifier,
    title: d.title || d.identifier,
    artist: first(d.creator) || 'Unknown artist',
    date: (d.date || '').slice(0, 10),
    venue: d.venue || '',
    place: d.coverage || '',
    art: null,
  }))
}

const BASE = 'collection:etree AND mediatype:etree'

export function searchShows(q: string, signal?: AbortSignal) {
  const c = clean(q)
  if (!c) return Promise.resolve([])
  return find(`${BASE} AND (creator:(${c}) OR title:(${c}))`, 12, signal)
}

export const legendaryShows = (signal?: AbortSignal) => find(BASE, 12, signal)

function seconds(len?: string) {
  if (!len) return 0
  if (len.includes(':')) return len.split(':').reduce((acc, p) => acc * 60 + Number(p || 0), 0)
  return Number(len) || 0
}

export async function showTracks(id: string, signal?: AbortSignal): Promise<{ show: Show; tracks: Track[] }> {
  const res = await fetch(`https://archive.org/metadata/${encodeURIComponent(id)}`, { signal })
  if (!res.ok) throw new Error(`Live Archive answered ${res.status}`)
  const m = (await res.json()) as RawMeta
  const md = m.metadata ?? {}
  const show: Show = {
    id,
    title: md.title || id,
    artist: first(md.creator) || 'Unknown artist',
    date: (md.date || '').slice(0, 10),
    venue: md.venue || '',
    place: md.coverage || '',
    art: null,
  }
  const files = (m.files ?? []).filter((f) => f.name.toLowerCase().endsWith('.mp3'))
  // Prefer the archive's own VBR derivatives; fall back to whatever mp3s exist.
  const vbr = files.filter((f) => (f.format || '').startsWith('VBR'))
  const use = (vbr.length ? vbr : files).sort((a, b) => {
    const ta = Number(a.track) || 0
    const tb = Number(b.track) || 0
    return ta && tb ? ta - tb : a.name.localeCompare(b.name)
  })
  const where = [show.venue, show.date].filter(Boolean).join(' · ')
  const tracks: Track[] = use.map((f) => ({
    id: `ia:${id}/${f.name}`,
    title: (f.title || f.name.replace(/\.mp3$/i, '')).trim(),
    artist: f.creator || show.artist,
    genre: 'Live',
    mood: '',
    duration: seconds(f.length),
    art: null,
    artLarge: null,
    permalink: `https://archive.org/details/${encodeURIComponent(id)}`,
    source: 'archive',
    stream: `https://archive.org/download/${encodeURIComponent(id)}/${encodeURIComponent(f.name)}`,
    subtitle: where,
  }))
  return { show, tracks }
}
