const API = 'https://api.audius.co/v1'
const APP = 'aether_player'

export type Source = 'audius' | 'archive' | 'youtube'

export type Track = {
  id: string
  title: string
  artist: string
  genre: string
  mood: string
  duration: number
  art: string | null
  artLarge: string | null
  permalink: string
  /** Absent on tracks saved before sources existed: those are Audius. */
  source?: Source
  /** Direct audio URL when it isn't derivable from the id (Live Archive). */
  stream?: string
  /** Extra line, e.g. "Barton Hall, Cornell University · 1977-05-08". */
  subtitle?: string
}

export type Artist = { id: string; name: string; handle: string; avatar: string | null; followers: number; tracks: number }
export type Collection = { id: string; name: string; owner: string; art: string | null; count: number }

export const GENRES = [
  'Electronic', 'House', 'Techno', 'Hip-Hop/Rap', 'R&B/Soul', 'Lo-Fi', 'Ambient', 'Pop',
  'Dubstep', 'Drum & Bass', 'Trap', 'Alternative', 'Jazz', 'Rock', 'Latin', 'Experimental',
]

type RawTrack = {
  id: string
  title: string
  genre?: string
  mood?: string | null
  duration: number
  permalink?: string
  is_streamable?: boolean
  is_stream_gated?: boolean
  is_delete?: boolean
  artwork?: Record<string, string> | null
  user?: { name?: string; handle?: string }
}
type RawUser = {
  id: string
  name: string
  handle: string
  track_count: number
  follower_count: number
  profile_picture?: Record<string, string> | null
}
type RawPlaylist = {
  id: string
  playlist_name: string
  track_count?: number
  artwork?: Record<string, string> | null
  user?: { name?: string }
  is_stream_gated?: boolean
}

function toTrack(t: RawTrack): Track {
  return {
    id: t.id,
    title: (t.title || 'Untitled').trim(),
    artist: t.user?.name || t.user?.handle || 'Unknown artist',
    genre: t.genre || 'Unknown',
    mood: t.mood || '',
    duration: t.duration || 0,
    art: t.artwork?.['480x480'] ?? t.artwork?.['150x150'] ?? null,
    artLarge: t.artwork?.['1000x1000'] ?? t.artwork?.['480x480'] ?? null,
    permalink: t.permalink ? `https://audius.co${t.permalink}` : 'https://audius.co',
    source: 'audius',
  }
}

async function getJson<T>(path: string, params: Record<string, string>, signal?: AbortSignal): Promise<T[]> {
  const q = new URLSearchParams({ app_name: APP, ...params })
  const res = await fetch(`${API}${path}?${q}`, { signal })
  if (!res.ok) throw new Error(`Audius answered ${res.status}`)
  const body = (await res.json()) as { data?: T[] }
  return body.data ?? []
}

const tracks = async (path: string, params: Record<string, string>, signal?: AbortSignal) =>
  (await getJson<RawTrack>(path, params, signal))
    .filter((t) => t.is_streamable !== false && !t.is_stream_gated && !t.is_delete)
    .map(toTrack)

export const trending = (genre: string | null, signal?: AbortSignal) =>
  tracks('/tracks/trending', genre ? { genre, time: 'week', limit: '60' } : { time: 'week', limit: '60' }, signal)

export const underground = (signal?: AbortSignal) => tracks('/tracks/trending/underground', { limit: '30' }, signal)

export const searchTracks = (query: string, offset = 0, signal?: AbortSignal) =>
  tracks('/tracks/search', { query, limit: '40', offset: String(offset) }, signal)

export async function searchArtists(query: string, signal?: AbortSignal): Promise<Artist[]> {
  const users = await getJson<RawUser>('/users/search', { query, limit: '12' }, signal)
  return users
    .filter((u) => u.track_count > 0)
    .map((u) => ({
      id: u.id,
      name: u.name || u.handle,
      handle: u.handle,
      avatar: u.profile_picture?.['150x150'] ?? null,
      followers: u.follower_count,
      tracks: u.track_count,
    }))
}

export const artistTracks = (id: string, signal?: AbortSignal) =>
  tracks(`/users/${encodeURIComponent(id)}/tracks`, { limit: '50', sort: 'plays' }, signal)

const toCollection = (p: RawPlaylist): Collection => ({
  id: p.id,
  name: p.playlist_name,
  owner: p.user?.name || 'Audius',
  art: p.artwork?.['480x480'] ?? p.artwork?.['150x150'] ?? null,
  count: p.track_count ?? 0,
})

export const trendingPlaylists = async (signal?: AbortSignal) =>
  (await getJson<RawPlaylist>('/playlists/trending', { limit: '12', time: 'week' }, signal)).filter((p) => !p.is_stream_gated).map(toCollection)

export const searchPlaylists = async (query: string, signal?: AbortSignal) =>
  (await getJson<RawPlaylist>('/playlists/search', { query, limit: '8' }, signal)).filter((p) => !p.is_stream_gated).map(toCollection)

export const playlistTracks = (id: string, signal?: AbortSignal) => tracks(`/playlists/${encodeURIComponent(id)}/tracks`, {}, signal)

export const streamUrl = (id: string) => `${API}/tracks/${encodeURIComponent(id)}/stream?app_name=${APP}`

export const trackStream = (t: Track) => t.stream ?? streamUrl(t.id)

export function hashId(id: string) {
  let h = 2166136261
  for (let i = 0; i < id.length; i++) h = Math.imul(h ^ id.charCodeAt(i), 16777619)
  return ((h >>> 0) % 10000) / 10000
}

/** Old saved tracks may be missing newer fields; make them safe to use. */
export function sanitizeTrack(t: unknown): Track | null {
  if (!t || typeof t !== 'object') return null
  const x = t as Partial<Track>
  if (typeof x.id !== 'string' || typeof x.title !== 'string') return null
  return {
    id: x.id,
    title: x.title,
    artist: typeof x.artist === 'string' ? x.artist : 'Unknown artist',
    genre: typeof x.genre === 'string' ? x.genre : 'Unknown',
    mood: typeof x.mood === 'string' ? x.mood : '',
    duration: typeof x.duration === 'number' ? x.duration : 0,
    art: typeof x.art === 'string' ? x.art : null,
    artLarge: typeof x.artLarge === 'string' ? x.artLarge : null,
    permalink: typeof x.permalink === 'string' ? x.permalink : 'https://audius.co',
    source: x.source === 'archive' || x.source === 'youtube' ? x.source : 'audius',
    stream: typeof x.stream === 'string' ? x.stream : undefined,
    subtitle: typeof x.subtitle === 'string' ? x.subtitle : undefined,
  }
}
