import type { Track } from './audius'

/**
 * Official songs via YouTube. YouTube's rules: the video stays visible in its own player,
 * and its audio is never altered. Aether follows both, so these songs skip the Sound Shape.
 *
 * Quota note: a free API key gets 10,000 units a day. A search costs 100 units, so searches
 * are cached and only sent once typing settles. Trending and details cost 1 unit each.
 */

const API = 'https://www.googleapis.com/youtube/v3'

export const ENV_KEY = (import.meta.env.VITE_YOUTUBE_KEY as string | undefined)?.trim() || null

export class YouTubeError extends Error {
  constructor(
    public kind: 'quota' | 'key' | 'network',
    message: string,
  ) {
    super(message)
  }
}

type Snippet = {
  title: string
  channelTitle: string
  thumbnails?: Record<string, { url: string }>
  liveBroadcastContent?: string
}
type Video = { id: string; snippet: Snippet; contentDetails?: { duration?: string } }
type SearchItem = { id: { videoId?: string }; snippet: Snippet }

async function call<T>(path: string, params: Record<string, string>, key: string, signal?: AbortSignal): Promise<T> {
  let res: Response
  try {
    res = await fetch(`${API}${path}?${new URLSearchParams({ ...params, key })}`, { signal })
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw e
    throw new YouTubeError('network', "Couldn't reach YouTube. Check your connection.")
  }
  if (res.ok) return (await res.json()) as T
  let reason = ''
  try {
    const body = (await res.json()) as { error?: { errors?: { reason?: string }[] } }
    reason = body.error?.errors?.[0]?.reason ?? ''
  } catch {
    /* no body */
  }
  if (reason.includes('quota') || reason === 'rateLimitExceeded') {
    throw new YouTubeError('quota', "YouTube's free daily search limit for your key is used up. It resets at midnight Pacific time.")
  }
  if (res.status === 400 || res.status === 403) {
    throw new YouTubeError('key', "YouTube didn't accept this API key. Check that YouTube Data API v3 is enabled for it.")
  }
  throw new YouTubeError('network', `YouTube answered ${res.status}. Try again in a moment.`)
}

const decode = (s: string) => {
  const el = document.createElement('textarea')
  el.innerHTML = s
  return el.value
}

const NOISE = /\s*[([](official\s*(music\s*)?(video|audio|visuali[sz]er|lyric video)|lyrics?( video)?|audio|hd|4k|visuali[sz]er|explicit)[)\]]/gi

function cleanArtist(channel: string) {
  return channel.replace(/\s*-\s*Topic$/i, '').replace(/VEVO$/i, '').trim()
}

/** "Drake - God's Plan (Official Video)" from channel "DrakeVEVO" → title "God's Plan", artist "Drake". */
function split(rawTitle: string, channel: string) {
  const t = decode(rawTitle).replace(NOISE, '').trim()
  const artist = cleanArtist(decode(channel))
  const dash = t.indexOf(' - ')
  if (dash > 0) {
    const left = t.slice(0, dash).trim()
    const right = t.slice(dash + 3).trim()
    if (left.toLowerCase().includes(artist.toLowerCase()) || artist.toLowerCase().includes(left.toLowerCase())) {
      return { title: right, artist: left }
    }
  }
  return { title: t, artist }
}

const official = (channel: string, title: string) =>
  (/ - Topic$/i.test(channel) ? 3 : 0) + (/VEVO$/i.test(channel) ? 3 : 0) + (/official/i.test(title) ? 1 : 0)

function iso(d?: string) {
  const m = d?.match(/P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/)
  if (!m) return 0
  return (+(m[1] || 0)) * 86400 + (+(m[2] || 0)) * 3600 + (+(m[3] || 0)) * 60 + +(m[4] || 0)
}

function toTrack(v: Video): Track {
  const { title, artist } = split(v.snippet.title, v.snippet.channelTitle)
  const th = v.snippet.thumbnails ?? {}
  return {
    id: `yt:${v.id}`,
    title,
    artist,
    genre: 'Unknown',
    mood: '',
    duration: iso(v.contentDetails?.duration),
    art: th.high?.url ?? th.medium?.url ?? th.default?.url ?? null,
    artLarge: th.maxres?.url ?? th.high?.url ?? null,
    permalink: `https://www.youtube.com/watch?v=${v.id}`,
    source: 'youtube',
    subtitle: 'YouTube',
  }
}

export const youtubeId = (t: Track) => (t.id.startsWith('yt:') ? t.id.slice(3) : null)

const region = () => {
  try {
    const r = new Intl.Locale(navigator.language).maximize().region
    return r && /^[A-Z]{2}$/.test(r) ? r : 'US'
  } catch {
    return 'US'
  }
}

const cache = new Map<string, Track[]>()

/** The most-watched music videos in your country right now. 1 unit. */
export async function trendingVideos(key: string, signal?: AbortSignal): Promise<Track[]> {
  const ck = `trending:${region()}`
  const hit = cache.get(ck)
  if (hit) return hit
  const body = await call<{ items?: Video[] }>(
    '/videos',
    { part: 'snippet,contentDetails', chart: 'mostPopular', videoCategoryId: '10', regionCode: region(), maxResults: '30' },
    key,
    signal,
  )
  const out = (body.items ?? []).map(toTrack)
  cache.set(ck, out)
  return out
}

/** Official songs for a search. 101 units, cached per query. */
export async function searchVideos(q: string, key: string, signal?: AbortSignal): Promise<Track[]> {
  const ck = `q:${q.toLowerCase()}`
  const hit = cache.get(ck)
  if (hit) return hit
  const found = await call<{ items?: SearchItem[] }>(
    '/search',
    { part: 'snippet', type: 'video', videoCategoryId: '10', videoEmbeddable: 'true', maxResults: '20', q },
    key,
    signal,
  )
  const ids = (found.items ?? []).map((i) => i.id.videoId).filter(Boolean) as string[]
  if (!ids.length) {
    cache.set(ck, [])
    return []
  }
  const details = await call<{ items?: Video[] }>('/videos', { part: 'snippet,contentDetails', id: ids.join(',') }, key, signal)
  const byId = new Map((details.items ?? []).map((v) => [v.id, v]))
  const out = ids
    .map((id) => byId.get(id))
    .filter((v): v is Video => !!v && v.snippet.liveBroadcastContent !== 'live')
    .map((v, i) => ({ v, score: official(v.snippet.channelTitle, v.snippet.title) * 10 - i }))
    .sort((a, b) => b.score - a.score)
    .map(({ v }) => toTrack(v))
  cache.set(ck, out)
  return out
}

/** Cheap check that a pasted key works (1 unit). */
export async function checkKey(key: string) {
  await call('/videos', { part: 'id', chart: 'mostPopular', videoCategoryId: '10', maxResults: '1' }, key)
}
