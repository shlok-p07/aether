import { createContext, useContext, useEffect, useState } from 'react'
import type { Track } from '../data/audius'
import type { Playlist } from '../taste/profile'

export type LibraryApi = {
  currentId: string | null
  playing: boolean
  liked: Record<string, Track>
  playlists: Playlist[]
  recent: string[]
  toggleLike: (t: Track) => void
  play: (list: Track[], index: number) => void
  createPlaylist: (name: string, first?: Track) => string
  renamePlaylist: (id: string, name: string) => void
  deletePlaylist: (id: string) => void
  toggleInPlaylist: (id: string, t: Track) => void
  removeFromPlaylist: (id: string, trackId: string) => void
  movePlaylistTrack: (id: string, from: number, to: number) => void
  addRecent: (q: string) => void
  clearRecent: () => void
  /** The listener's YouTube Data API key (or one from .env.local); null when not connected. */
  ytKey: string | null
  setYtKey: (k: string | null) => void
}

export const LibraryContext = createContext<LibraryApi | null>(null)

export function useLibrary() {
  const v = useContext(LibraryContext)
  if (!v) throw new Error('useLibrary needs <LibraryContext.Provider>')
  return v
}

export type Async<T> = { status: 'loading' | 'ready' | 'error'; data: T | null; retry: () => void }

/** Fetch with abort-on-change, loading and error states, and a retry. */
export function useAsync<T>(fn: ((signal: AbortSignal) => Promise<T>) | null, deps: unknown[]): Async<T> {
  const [state, setState] = useState<{ status: Async<T>['status']; data: T | null }>({ status: 'loading', data: null })
  const [n, setN] = useState(0)
  useEffect(() => {
    if (!fn) return
    const ac = new AbortController()
    setState((s) => ({ status: 'loading', data: s.data }))
    fn(ac.signal)
      .then((data) => setState({ status: 'ready', data }))
      .catch((e) => {
        if ((e as Error).name !== 'AbortError') setState({ status: 'error', data: null })
      })
    return () => ac.abort()
  }, [...deps, n]) // eslint-disable-line react-hooks/exhaustive-deps
  return { ...state, retry: () => setN((x) => x + 1) }
}

export const fmtTime = (s: number) => {
  if (!Number.isFinite(s) || s <= 0) return ''
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = String(Math.floor(s % 60)).padStart(2, '0')
  return h ? `${h}:${String(m).padStart(2, '0')}:${sec}` : `${m}:${sec}`
}
