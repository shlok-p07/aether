import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import '@fontsource/shrikhand/400.css'
import './styles.css'
import App from './App'
import { bus } from './visual/bus'

if (import.meta.env.DEV) (window as unknown as { __aetherBus: typeof bus }).__aetherBus = bus

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
