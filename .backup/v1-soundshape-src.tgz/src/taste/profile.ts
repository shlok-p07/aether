import { AXES, STARTER, add, distance, mix, sanitize, type Shape } from '../audio/shape'
import { sanitizeTrack, type Track } from '../data/audius'
import type { Tilt } from '../audio/engine'

export type GenreMemory = { shape: Shape; n: number }

export type Playlist = { id: string; name: string; tracks: Track[]; created: number }

export type Profile = {
  v: 1
  base: Shape
  setupDone: boolean
  genres: Record<string, GenreMemory>
  loved: Record<string, Track>
  /** Running average of the tonal balance of songs this listener plays. */
  tilt: { low: number; high: number; n: number }
  autoTune: boolean
  calm: boolean
  playlists: Playlist[]
  recentSearches: string[]
  youtubeKey: string | null
}

const KEY = 'aether.profile.v1'

export function emptyProfile(): Profile {
  return {
    v: 1,
    base: { ...STARTER },
    setupDone: false,
    genres: {},
    loved: {},
    tilt: { low: 0, high: 0, n: 0 },
    autoTune: true,
    calm: false,
    playlists: [],
    recentSearches: [],
    youtubeKey: null,
  }
}

function sanitizeLoved(raw: unknown): Record<string, Track> {
  const out: Record<string, Track> = {}
  if (raw && typeof raw === 'object') {
    for (const v of Object.values(raw as Record<string, unknown>)) {
      const t = sanitizeTrack(v)
      if (t) out[t.id] = t
    }
  }
  return out
}

function sanitizePlaylists(raw: unknown): Playlist[] {
  if (!Array.isArray(raw)) return []
  return raw
    .filter((p) => p && typeof p.id === 'string' && typeof p.name === 'string')
    .map((p) => ({
      id: p.id,
      name: p.name,
      created: typeof p.created === 'number' ? p.created : Date.now(),
      tracks: Array.isArray(p.tracks) ? (p.tracks.map(sanitizeTrack).filter(Boolean) as Track[]) : [],
    }))
}

export function loadProfile(): Profile {
  const fresh = emptyProfile()
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return fresh
    const p = JSON.parse(raw) as Partial<Profile>
    const genres: Record<string, GenreMemory> = {}
    for (const [g, m] of Object.entries(p.genres ?? {})) {
      if (m && typeof m.n === 'number') genres[g] = { shape: sanitize(m.shape, fresh.base), n: m.n }
    }
    return {
      ...fresh,
      base: sanitize(p.base, fresh.base),
      setupDone: !!p.setupDone,
      genres,
      loved: sanitizeLoved(p.loved),
      tilt: p.tilt && typeof p.tilt.n === 'number' ? p.tilt : fresh.tilt,
      autoTune: p.autoTune !== false,
      calm: !!p.calm,
      playlists: sanitizePlaylists(p.playlists),
      youtubeKey: typeof p.youtubeKey === 'string' && p.youtubeKey ? p.youtubeKey : null,
      recentSearches: Array.isArray(p.recentSearches) ? p.recentSearches.filter((x) => typeof x === 'string').slice(0, 8) : [],
    }
  } catch {
    return fresh
  }
}

export function saveProfile(p: Profile) {
  try {
    localStorage.setItem(KEY, JSON.stringify(p))
  } catch {
    /* private mode or storage blocked: Aether still works, it just forgets on reload */
  }
}

export type Tuning = {
  shape: Shape
  /** Human sentence for where the shape came from. */
  source: string
  genre: string
}

/** The shape Aether reaches for when a song starts: your base, pulled toward what you taught it for this genre. */
export function shapeFor(p: Profile, track: Track | null): Tuning {
  const genre = track?.genre || 'Unknown'
  const mem = p.genres[genre]
  if (!mem || mem.n === 0) {
    return { shape: p.base, source: p.setupDone ? 'your taste' : 'a starter shape', genre }
  }
  const confidence = mem.n / (mem.n + 1.5)
  return {
    shape: mix(p.base, mem.shape, confidence),
    source: `your ${genre} shape, learned from ${mem.n} ${mem.n === 1 ? 'adjustment' : 'adjustments'}`,
    genre,
  }
}

/** Remember a manual adjustment: it teaches this genre strongly and your overall taste a little. */
export function learn(p: Profile, genre: string, shape: Shape, from: Shape): Profile {
  if (distance(shape, from) < 0.04) return p
  const prev = p.genres[genre] ?? { shape: p.base, n: 0 }
  return {
    ...p,
    genres: { ...p.genres, [genre]: { shape: mix(prev.shape, shape, 0.55), n: prev.n + 1 } },
    base: mix(p.base, shape, 0.12),
  }
}

/** Loving a song while it sounds like this is a vote for this shape in its genre. */
export function reinforce(p: Profile, genre: string, shape: Shape): Profile {
  const prev = p.genres[genre]
  return {
    ...p,
    genres: {
      ...p.genres,
      [genre]: prev ? { shape: mix(prev.shape, shape, 0.3), n: prev.n + 1 } : { shape: { ...shape }, n: 1 },
    },
  }
}

export type Adaptation ={ delta: Partial<Shape>; reasons: string[] }

/**
 * Per-song fit. Compares this song's own tonal balance to what you usually play and leans
 * into your taste: a bass lover gets more lift on a thin track than someone who prefers detail.
 * Returns null until there is enough history to compare against.
 */
export function adaptToTrack(p: Profile, shape: Shape, tilt: Tilt): Adaptation | null {
  if (p.tilt.n < 2) return null
  const lowGap = p.tilt.low - tilt.low // positive: lighter low end than usual
  const highGap = p.tilt.high - tilt.high // positive: duller top than usual
  const delta: Partial<Shape> = {}
  const reasons: string[] = []

  if (Math.abs(lowGap) > 2.5) {
    const want = 0.35 + shape.bass
    const d = Math.max(-0.2, Math.min(0.25, (lowGap / 14) * want))
    if (Math.abs(d) >= 0.04) {
      delta.bass = d
      reasons.push(d > 0 ? 'lighter on low end than what you usually play' : 'heavier on low end than what you usually play')
    }
  }
  if (Math.abs(highGap) > 3) {
    const want = 0.35 + shape.air
    const d = Math.max(-0.15, Math.min(0.2, (highGap / 16) * want))
    if (Math.abs(d) >= 0.04) {
      delta.air = d
      reasons.push(d > 0 ? 'duller up top than you like' : 'brighter up top than you usually play')
    }
  }
  // People who love a live room hear dry mixes as flat; open them up a little more.
  if (shape.room > 0.45 && lowGap > 0 && highGap > 0) {
    delta.room = 0.06
  }
  return reasons.length ? { delta, reasons } : null
}

export function recordTilt(p: Profile, tilt: Tilt): Profile {
  const n = Math.min(p.tilt.n + 1, 40) // a long memory, but recent listening still moves it
  return {
    ...p,
    tilt: {
      low: p.tilt.low + (tilt.low - p.tilt.low) / n,
      high: p.tilt.high + (tilt.high - p.tilt.high) / n,
      n,
    },
  }
}

export function applyAdaptation(shape: Shape, a: Adaptation | null) {
  return a ? add(shape, a.delta) : shape
}

export function describeDelta(a: Adaptation) {
  const parts: string[] = []
  for (const k of AXES) {
    const d = a.delta[k]
    if (d && Math.abs(d) >= 0.04 && (k === 'bass' || k === 'air')) {
      parts.push(`${k === 'bass' ? 'Bass' : 'Air'} ${d > 0 ? '+' : '−'}${Math.round(Math.abs(d) * 100)}%`)
    }
  }
  return parts.join(', ')
}
