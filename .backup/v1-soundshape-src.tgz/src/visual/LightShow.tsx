import { useEffect, useRef } from 'react'
import { AXES } from '../audio/shape'
import type { Bands } from '../audio/engine'
import { bus, dyes } from './bus'

const VERT = `attribute vec2 a; void main(){ gl_Position = vec4(a, 0.0, 1.0); }`

const FRAG = `
precision highp float;
uniform vec2 uRes;
uniform float uTime;
uniform vec3 uBands;
uniform float uShape[7];
uniform vec3 uDish;
uniform vec3 uPush;
uniform float uRot;
uniform float uSeed;
uniform float uDom;

uniform vec3 uDye[4];
const vec3 WALL = vec3(0.071, 0.039, 0.122);
const vec3 LAMP = vec3(1.0, 0.957, 0.878);

vec3 permute(vec3 x){ return mod(((x*34.0)+1.0)*x, 289.0); }
float snoise(vec2 v){
  const vec4 C = vec4(0.211324865405187, 0.366025403784439, -0.577350269189626, 0.024390243902439);
  vec2 i = floor(v + dot(v, C.yy));
  vec2 x0 = v - i + dot(i, C.xx);
  vec2 i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
  vec4 x12 = x0.xyxy + C.xxzz; x12.xy -= i1;
  i = mod(i, 289.0);
  vec3 p = permute(permute(i.y + vec3(0.0, i1.y, 1.0)) + i.x + vec3(0.0, i1.x, 1.0));
  vec3 m = max(0.5 - vec3(dot(x0,x0), dot(x12.xy,x12.xy), dot(x12.zw,x12.zw)), 0.0);
  m = m*m; m = m*m;
  vec3 x = 2.0 * fract(p * C.www) - 1.0;
  vec3 h = abs(x) - 0.5;
  vec3 ox = floor(x + 0.5);
  vec3 a0 = x - ox;
  m *= 1.79284291400159 - 0.85373472095314 * (a0*a0 + h*h);
  vec3 g;
  g.x = a0.x * x0.x + h.x * x0.y;
  g.yz = a0.yz * x12.xz + h.yz * x12.yw;
  return 130.0 * dot(m, g);
}

float blobs(vec2 p, float s, float t, float spread){
  float f = 0.0;
  for (int i = 0; i < 6; i++) {
    float fi = float(i);
    float a = t * (0.07 + 0.021 * fi) + s * 6.283 + fi * 2.39;
    float b = t * (0.053 + 0.017 * fi) + s * 3.7 + fi * 1.31;
    vec2 c = vec2(sin(a) * cos(b * 0.7), sin(b) * cos(a * 0.6)) * spread;
    float r = 0.15 + 0.07 * fract(sin((fi + s * 13.0) * 12.9898) * 43758.5453);
    vec2 d = p - c;
    f += r * r / (dot(d, d) + 0.002);
  }
  return f;
}

void take(float f, vec3 c, inout float a1, inout float a2, inout vec3 c1){
  if (f > a1) { a2 = a1; a1 = f; c1 = c; }
  else if (f > a2) { a2 = f; }
}

void main(){
  vec2 frag = gl_FragCoord.xy;
  float R = uDish.z;
  vec2 q = (frag - uDish.xy) / R;
  float r = length(q);
  float bass = uShape[0], warm = uShape[1], room = uShape[2], width = uShape[3];
  float air = uShape[5], punch = uShape[6];
  float t = uTime;

  vec2 pp = (uPush.xy - uDish.xy) / R;
  vec2 dp = q - pp;
  float push = uPush.z * exp(-dot(dp, dp) * 5.0);
  vec2 p = q - normalize(dp + 1e-4) * push * 0.4;

  float cr = cos(uRot), sr = sin(uRot);
  p = mat2(cr, -sr, sr, cr) * p;
  p.x /= 1.0 + 0.45 * width;
  p /= 1.0 + uBands.x * (0.22 + 0.5 * bass) + punch * uBands.x * 0.12;
  vec2 w = vec2(snoise(p * 1.3 + vec2(t * 0.05, uSeed * 10.0)), snoise(p * 1.3 + vec2(4.2, -t * 0.05)));
  p += w * (0.09 + 0.12 * room);

  float spread = 0.55 + 0.25 * room;
  float f0 = blobs(p, uSeed, t, spread) * (1.0 + 0.5 * warm);
  float f1 = blobs(p, uSeed + 0.31, t * 1.1, spread) * (0.7 + 0.9 * warm);
  float f2 = blobs(p, uSeed + 0.57, t * 0.9, spread) * (0.75 + 0.8 * air);
  float f3 = blobs(p, uSeed + 0.83, t * 1.05, spread) * (0.9 + 0.4 * room);
  if (uDom < 0.5) f0 *= 1.35; else if (uDom < 1.5) f1 *= 1.35; else if (uDom < 2.5) f2 *= 1.35; else f3 *= 1.35;

  float a1 = 0.0, a2 = 0.0; vec3 col = WALL;
  take(f0, uDye[0], a1, a2, col);
  take(f1, uDye[1], a1, a2, col);
  take(f2, uDye[2], a1, a2, col);
  take(f3, uDye[3], a1, a2, col);

  vec3 clear = WALL * 1.6 + LAMP * 0.09;
  float body = smoothstep(0.86, 0.93, a1);
  float ring = smoothstep(0.35, 0.65, 0.5 + 0.5 * cos(log(a1) * 9.0 - t * 0.5));
  col *= 0.76 + 0.24 * ring * smoothstep(9.0, 2.0, a1);
  vec3 dye = mix(clear, col, body);
  float edge = 1.0 - smoothstep(0.0, 0.05 * a1, a1 - a2);
  dye = mix(dye, LAMP, edge * 0.5 * body);
  float bub = snoise(p * 7.0 + vec2(0.0, t * 0.3));
  float lift = 0.3 * uBands.z * (0.5 + air);
  float hb = smoothstep(0.86 - lift, 0.885 - lift, bub);
  float bubRim = hb * (1.0 - smoothstep(0.885 - lift, 0.91 - lift, bub));
  dye = mix(dye, clear * 1.5, hb * 0.8);
  dye = mix(dye, LAMP, bubRim * 0.35 * body);

  float hot = 1.06 - 0.26 * r * r;
  float rimG = 1.0 - smoothstep(0.985, 1.0, r);
  float rimR = 1.0 - smoothstep(0.99, 1.006, r);
  float rimB = 1.0 - smoothstep(0.975, 0.992, r);
  vec3 lit = dye * hot;
  vec3 inside = vec3(lit.r * rimR, lit.g * rimG, lit.b * rimB);
  vec3 spill = WALL + dye * 0.1 * (1.0 - smoothstep(1.0, 2.6, r));
  vec3 c = inside + spill * (1.0 - rimG);
  c += (fract(sin(dot(frag, vec2(12.9898, 78.233)) + t) * 43758.5453) - 0.5) * 0.022;
  gl_FragColor = vec4(c, 1.0);
}
`

type Props = { readBands: (out: Bands) => Bands }

export function LightShow({ readBands }: Props) {
  const ref = useRef<HTMLCanvasElement>(null)
  const readRef = useRef(readBands)
  readRef.current = readBands

  useEffect(() => {
    const canvas = ref.current
    if (!canvas) return
    const gl = canvas.getContext('webgl', { antialias: false, alpha: false, powerPreference: 'high-performance' })
    if (!gl) {
      canvas.dataset.fallback = 'true'
      return
    }
    const compile = (type: number, src: string) => {
      const s = gl.createShader(type)!
      gl.shaderSource(s, src)
      gl.compileShader(s)
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) console.error(gl.getShaderInfoLog(s))
      return s
    }
    const prog = gl.createProgram()!
    gl.attachShader(prog, compile(gl.VERTEX_SHADER, VERT))
    gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FRAG))
    gl.linkProgram(prog)
    gl.useProgram(prog)
    const buf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, buf)
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW)
    const loc = gl.getAttribLocation(prog, 'a')
    gl.enableVertexAttribArray(loc)
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0)
    const u = (n: string) => gl.getUniformLocation(prog, n)
    const U = {
      res: u('uRes'), time: u('uTime'), bands: u('uBands'), shape: u('uShape'), dish: u('uDish'),
      push: u('uPush'), rot: u('uRot'), seed: u('uSeed'), dom: u('uDom'), dye: u('uDye'),
    }

    let pr = 1
    const resize = () => {
      const w = canvas.clientWidth
      const h = canvas.clientHeight
      pr = Math.min(window.devicePixelRatio || 1, w < 700 ? 1.25 : 1.5)
      const W = Math.max(1, Math.round(w * pr))
      const H = Math.max(1, Math.round(h * pr))
      if (canvas.width !== W || canvas.height !== H) {
        canvas.width = W
        canvas.height = H
        gl.viewport(0, 0, W, H)
      }
    }
    resize()
    window.addEventListener('resize', resize)

    const sm = { low: 0, mid: 0, high: 0 }
    const raw = { low: 0, mid: 0, high: 0, level: 0 }
    const shapeArr = new Float32Array(7)
    let t = 0
    let rot = 0
    let last = performance.now()
    let raf = 0

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000)
      last = now
      resize() // cheap; catches viewport changes that fire no resize event (mobile URL bar, emulation)
      const calm = bus.calm
      const speed = calm ? 0.25 : bus.playing ? 1 : 0.45
      t += dt * speed

      readRef.current(raw)
      const k = (x: number, y: number) => (y > x ? 0.35 : 0.08) // fast attack, slow release
      sm.low += (raw.low - sm.low) * k(sm.low, raw.low)
      sm.mid += (raw.mid - sm.mid) * k(sm.mid, raw.mid)
      sm.high += (raw.high - sm.high) * k(sm.high, raw.high)
      const react = calm ? 0.15 : 1
      bus.bands.low = sm.low * react
      bus.bands.mid = sm.mid * react
      bus.bands.high = sm.high * react

      rot += dt * speed * (0.015 + bus.shape.orbit * 0.5)
      if (!bus.push.active) bus.push.amt *= Math.pow(0.04, dt)

      AXES.forEach((a, i) => (shapeArr[i] = bus.shape[a]))
      const H = canvas.height
      gl.uniform2f(U.res, canvas.width, H)
      gl.uniform1f(U.time, t)
      gl.uniform3f(U.bands, bus.bands.low, bus.bands.mid, bus.bands.high)
      gl.uniform1fv(U.shape, shapeArr)
      const r = Math.max(60, bus.dish.r)
      gl.uniform3f(U.dish, bus.dish.x * pr, H - bus.dish.y * pr, r * pr)
      gl.uniform3f(U.push, bus.push.x * pr, H - bus.push.y * pr, bus.push.amt)
      gl.uniform1f(U.rot, rot)
      gl.uniform1f(U.seed, bus.seed)
      gl.uniform1f(U.dom, bus.dominant)
      gl.uniform3fv(U.dye, dyes)
      gl.drawArrays(gl.TRIANGLES, 0, 3)
      raf = requestAnimationFrame(frame)
    }
    raf = requestAnimationFrame(frame)
    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', resize)
    }
  }, [])

  return <canvas ref={ref} className="lightshow" aria-hidden="true" />
}
