import { FLAT, type Shape } from '../audio/shape'
import type { Bands } from '../audio/engine'

/**
 * Per-frame values shared by the audio engine, the Sound Shape and the light show.
 * Kept outside React on purpose: these change 60 times a second.
 */
export const bus = {
  bands: { low: 0, mid: 0, high: 0, level: 0 } as Bands,
  shape: { ...FLAT } as Shape,
  /** Dish centre and radius in CSS pixels (viewport coordinates). */
  dish: { x: 0, y: 0, r: 0 },
  /** Where a shape point is being dragged; the dye flees from it. */
  push: { x: 0, y: 0, amt: 0, active: false },
  seed: 0.3,
  dominant: 0,
  playing: false,
  calm: false,
}

const MOOD_DYE: Record<string, number> = {
  Peaceful: 2, Tender: 2, Easygoing: 2, Melancholy: 3, Sophisticated: 3, Brooding: 3, Yearning: 3,
  Romantic: 0, Sensual: 0, Sentimental: 0, Upbeat: 1, Energizing: 1, Empowering: 1, Excited: 1,
  Rowdy: 0, Fiery: 0, Aggressive: 0, Defiant: 0, Gritty: 1, Cool: 2, Stirring: 3,
}

export const dyeForMood = (mood: string) => MOOD_DYE[mood] ?? 0

/** The four dyes of the show. Every song casts them differently: its mood picks the lead, its id deals the rest. */
const DYES: [number, number, number][] = [
  [1.0, 0.18, 0.533], // magenta
  [1.0, 0.69, 0.0], // amber
  [0.086, 0.78, 0.85], // cyan
  [0.48, 0.25, 0.89], // violet
]

export const dyes = new Float32Array(12)
export function setSongPalette(seed: number, mood: string) {
  const lead = dyeForMood(mood)
  const rest = [0, 1, 2, 3].filter((i) => i !== lead)
  // deal the other three into the remaining roles in a song-specific order
  const order = [rest, [rest[1], rest[2], rest[0]], [rest[2], rest[0], rest[1]], [rest[0], rest[2], rest[1]], [rest[1], rest[0], rest[2]], [rest[2], rest[1], rest[0]]][
    Math.floor(seed * 6) % 6
  ]
  ;[lead, ...order].forEach((d, i) => dyes.set(DYES[d], i * 3))
  bus.dominant = 0 // the lead dye always sits in slot 0
}
setSongPalette(0.3, '')
